// tarot-render.js (no module) -> exposes window.renderCardPNG(card, mode)

(function () {
    function seedFromString(str) {
      let h = 2166136261;
      for (let i = 0; i < str.length; i++) {
        h ^= str.charCodeAt(i);
        h = Math.imul(h, 16777619);
      }
      return h >>> 0;
    }
    function mulberry32(seed) {
      return function () {
        let t = (seed += 0x6D2B79F5);
        t = Math.imul(t ^ (t >>> 15), t | 1);
        t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
      };
    }
    function roundedRect(ctx, x, y, w, h, r) {
      ctx.beginPath();
      ctx.moveTo(x + r, y);
      ctx.arcTo(x + w, y, x + w, y + h, r);
      ctx.arcTo(x + w, y + h, x, y + h, r);
      ctx.arcTo(x, y + h, x, y, r);
      ctx.arcTo(x, y, x + w, y, r);
      ctx.closePath();
    }
    function drawNoise(ctx, w, h, alpha, rnd) {
      const img = ctx.getImageData(0, 0, w, h);
      const d = img.data;
      for (let i = 0; i < d.length; i += 4) {
        const n = (rnd() * 255) | 0;
        d[i] = d[i] * (1 - alpha) + n * alpha;
        d[i + 1] = d[i + 1] * (1 - alpha) + n * alpha;
        d[i + 2] = d[i + 2] * (1 - alpha) + n * alpha;
      }
      ctx.putImageData(img, 0, 0);
    }
    function drawScanlines(ctx, w, h, opacity) {
      ctx.save();
      ctx.globalAlpha = opacity;
      ctx.fillStyle = "#000";
      for (let y = 0; y < h; y += 4) ctx.fillRect(0, y, w, 1);
      ctx.restore();
    }
    function drawSymbol(ctx, cx, cy, size, kind, mode) {
      ctx.save();
      ctx.translate(cx, cy);
      ctx.lineWidth = 3;
      const accent = mode === "surface" ? "rgba(180,140,70,.85)" : "rgba(255,40,40,.75)";
      const ink = mode === "surface" ? "rgba(20,20,20,.85)" : "rgba(235,235,255,.85)";
      ctx.strokeStyle = accent;
  
      if (kind === "star") {
        ctx.beginPath();
        for (let i = 0; i < 5; i++) {
          const a = (Math.PI * 2 * i) / 5 - Math.PI / 2;
          ctx.lineTo(Math.cos(a) * size, Math.sin(a) * size);
          const a2 = a + Math.PI / 5;
          ctx.lineTo(Math.cos(a2) * size * 0.45, Math.sin(a2) * size * 0.45);
        }
        ctx.closePath();
        ctx.stroke();
      } else if (kind === "moon") {
        ctx.beginPath();
        ctx.arc(0, 0, size, -Math.PI / 2, Math.PI / 2);
        ctx.arc(size * 0.35, 0, size * 0.85, Math.PI / 2, -Math.PI / 2, true);
        ctx.closePath();
        ctx.stroke();
      } else if (kind === "eye") {
        ctx.beginPath();
        ctx.ellipse(0, 0, size * 1.25, size * 0.75, 0, 0, Math.PI * 2);
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(0, 0, size * 0.28, 0, Math.PI * 2);
        ctx.fillStyle = ink;
        ctx.fill();
      } else {
        const s = size * 1.15;
        for (let i = -2; i <= 2; i++) {
          ctx.beginPath();
          ctx.moveTo(-s, (i * s) / 2);
          ctx.lineTo(s, (i * s) / 2);
          ctx.stroke();
          ctx.beginPath();
          ctx.moveTo((i * s) / 2, -s);
          ctx.lineTo((i * s) / 2, s);
          ctx.stroke();
        }
        ctx.beginPath();
        ctx.arc(0, 0, size * 1.05, 0, Math.PI * 2);
        ctx.stroke();
      }
      ctx.restore();
    }
  
    window.renderCardPNG = function renderCardPNG(card, mode = "surface") {
      const W = 560, H = 840;
      const canvas = document.createElement("canvas");
      canvas.width = W; canvas.height = H;
      const ctx = canvas.getContext("2d");
  
      const seed = seedFromString(card.slug || card.name_en || "tarot");
      const rnd = mulberry32(seed);
      const symbols = ["star", "moon", "eye", "grid"];
      const kind = symbols[Math.floor(rnd() * symbols.length)];
  
      // background
      if (mode === "surface") {
        const g = ctx.createLinearGradient(0, 0, W, H);
        g.addColorStop(0, "#F6F1E6");
        g.addColorStop(1, "#EDE3D2");
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, W, H);
      } else {
        const g = ctx.createLinearGradient(0, 0, W, H);
        g.addColorStop(0, "#070A12");
        g.addColorStop(1, "#141A2A");
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, W, H);
        ctx.save();
        ctx.globalAlpha = 0.22;
        ctx.fillStyle = "#FF0033";
        ctx.beginPath();
        ctx.arc(W * 0.55, H * 0.42, W * 0.55, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }
  
      drawNoise(ctx, W, H, mode === "surface" ? 0.06 : 0.08, rnd);
  
      // frame
      const pad = 38, r = 26;
      ctx.save();
      roundedRect(ctx, pad, pad, W - pad * 2, H - pad * 2, r);
      ctx.clip();
  
      const inner = ctx.createLinearGradient(0, pad, W, H - pad);
      if (mode === "surface") {
        inner.addColorStop(0, "rgba(255,255,255,0.55)");
        inner.addColorStop(1, "rgba(240,228,208,0.35)");
      } else {
        inner.addColorStop(0, "rgba(20,24,40,0.55)");
        inner.addColorStop(1, "rgba(0,0,0,0.35)");
      }
      ctx.fillStyle = inner;
      ctx.fillRect(pad, pad, W - pad * 2, H - pad * 2);
  
      // particles
      ctx.save();
      ctx.globalAlpha = mode === "surface" ? 0.10 : 0.16;
      ctx.fillStyle = mode === "surface" ? "#B48C46" : "#FF0033";
      for (let i = 0; i < 90; i++) {
        const x = pad + rnd() * (W - pad * 2);
        const y = pad + rnd() * (H - pad * 2);
        const s = rnd() * 2.2;
        ctx.fillRect(x, y, s, s);
      }
      ctx.restore();
  
      ctx.restore();
  
      // strokes
      ctx.lineWidth = 3;
      ctx.strokeStyle = mode === "surface" ? "rgba(20,20,20,.45)" : "rgba(240,240,255,.35)";
      roundedRect(ctx, pad, pad, W - pad * 2, H - pad * 2, r);
      ctx.stroke();
  
      ctx.lineWidth = 2;
      ctx.strokeStyle = mode === "surface" ? "rgba(180,140,70,.70)" : "rgba(255,40,40,.65)";
      roundedRect(ctx, pad + 14, pad + 14, W - (pad + 14) * 2, H - (pad + 14) * 2, r - 10);
      ctx.stroke();
  
      // symbol
      drawSymbol(ctx, W / 2, H * 0.47, 84, kind, mode);
  
      // title + badge
      const title = card.name_zh || card.name_en || "Tarot";
      ctx.textAlign = "center";
      ctx.fillStyle = mode === "surface" ? "rgba(10,10,10,.88)" : "rgba(235,235,255,.88)";
      ctx.font = "600 34px Inter, system-ui, -apple-system, Arial";
      ctx.fillText(title, W / 2, H - 98);
  
      const badge = card.reversed ? "逆位" : "正位";
      ctx.fillStyle = mode === "surface" ? "rgba(10,10,10,.65)" : "rgba(235,235,255,.65)";
      ctx.font = "500 22px Inter, system-ui, -apple-system, Arial";
      ctx.fillText(badge, W / 2, H - 60);
  
      if (mode === "upside") {
        drawScanlines(ctx, W, H, 0.12);
        ctx.save();
        ctx.globalAlpha = 0.25;
        ctx.fillStyle = "#FF0033";
        ctx.fillRect(0, Math.floor(H * 0.28), W, 3);
        ctx.restore();
      }
  
      return canvas.toDataURL("image/png");
    };
  })();
  