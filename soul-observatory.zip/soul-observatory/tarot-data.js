// tarot-data.js (no module) -> exposes window.TAROT
window.TAROT = [
    { 
        id:"m00", 
        slug:"the-fool", 
        name_zh:"愚者", 
        name_en:"The Fool",
        core_zh:"新的开始，带着好奇前进",
        core_en:"New beginnings, moving forward with curiosity",
        upright: ["开始", "自由", "信任", "尝试"],
        reversed: ["鲁莽", "轻率", "忽视风险", "天真"]
    },
    { 
        id:"m01", 
        slug:"the-magician", 
        name_zh:"魔术师", 
        name_en:"The Magician",
        core_zh:"资源已齐，关键是专注与行动",
        core_en:"Resources are ready, focus and action are key",
        upright: ["显化", "技能", "主动", "专注"],
        reversed: ["操控", "分散", "偷懒捷径", "才华闲置"]
    },
    { 
        id:"m02", 
        slug:"the-high-priestess", 
        name_zh:"女祭司", 
        name_en:"The High Priestess",
        core_zh:"答案在内在，先降噪",
        core_en:"Answers lie within, first reduce the noise",
        upright: ["直觉", "潜意识", "洞察", "沉默"],
        reversed: ["忽视直觉", "迷雾", "秘密", "噪音"]
    },
    { 
        id:"m03", 
        slug:"the-empress", 
        name_zh:"女皇", 
        name_en:"The Empress",
        core_zh:"滋养与生长，允许获得",
        core_en:"Nurture and growth, allow yourself to receive",
        upright: ["丰盛", "照顾", "美", "创造"],
        reversed: ["过度付出", "依赖", "创作阻滞", "忽略自己"]
    },
    { 
        id:"m04", 
        slug:"the-emperor", 
        name_zh:"皇帝", 
        name_en:"The Emperor",
        core_zh:"建立结构与边界，给人生底盘",
        core_en:"Build structure and boundaries, give life a foundation",
        upright: ["秩序", "权威", "边界", "稳定"],
        reversed: ["控制欲", "僵硬", "强压", "不安全感"]
    },
    { 
        id:"m05", 
        slug:"the-hierophant", 
        name_zh:"教皇", 
        name_en:"The Hierophant",
        core_zh:"选择真正支持你的规则",
        core_en:"Choose rules that truly support you",
        upright: ["传统", "学习", "导师", "价值观"],
        reversed: ["反叛", "教条", "空规则", "不适配"]
    },
    { 
        id:"m06", 
        slug:"the-lovers", 
        name_zh:"恋人", 
        name_en:"The Lovers",
        core_zh:"你在选择：价值观对齐最重要",
        core_en:"You are choosing: alignment of values matters most",
        upright: ["结合", "选择", "一致", "承诺"],
        reversed: ["不一致", "诱惑", "关系失衡", "摇摆"]
    },
    { 
        id:"m07", 
        slug:"the-chariot", 
        name_zh:"战车", 
        name_en:"The Chariot",
        core_zh:"靠方向赢，不靠硬顶",
        core_en:"Win by direction, not by force",
        upright: ["意志", "推进", "胜利", "自控"],
        reversed: ["失控", "硬推", "疲惫", "卡住"]
    },
    { 
        id:"m08", 
        slug:"strength", 
        name_zh:"力量", 
        name_en:"Strength",
        core_zh:"温柔也能掌控",
        core_en:"Gentleness can also be in control",
        upright: ["勇气", "耐心", "自信", "柔性力量"],
        reversed: ["自我怀疑", "情绪失控", "恐惧", "脆弱自尊"]
    },
    { 
        id:"m09", 
        slug:"the-hermit", 
        name_zh:"隐者", 
        name_en:"The Hermit",
        core_zh:"后退一步看清全局",
        core_en:"Step back to see the bigger picture",
        upright: ["独处", "内省", "智慧", "灯塔"],
        reversed: ["孤立", "逃避", "迷失", "封闭"]
    },
    { 
        id:"m10", 
        slug:"wheel-of-fortune", 
        name_zh:"命运之轮", 
        name_en:"Wheel of Fortune",
        core_zh:"周期在转动，适应更重要",
        core_en:"The cycle is turning, adaptation matters more",
        upright: ["变化", "转折", "机遇", "循环"],
        reversed: ["抗拒变化", "停滞", "坏时机", "重复模式"]
    },
    { 
        id:"m11", 
        slug:"justice", 
        name_zh:"正义", 
        name_en:"Justice",
        core_zh:"现实审计：为自己的部分负责",
        core_en:"Reality audit: take responsibility for your part",
        upright: ["真相", "平衡", "因果", "清晰"],
        reversed: ["偏见", "不公", "否认", "逃避代价"]
    },
    { 
        id:"m12", 
        slug:"the-hanged-man", 
        name_zh:"倒吊人", 
        name_en:"The Hanged Man",
        core_zh:"别硬推，换角度就通了",
        core_en:"Don't force it, change perspective and it works",
        upright: ["暂停", "换视角", "臣服", "重构"],
        reversed: ["拖延", "卡死", "怨气", "无效牺牲"]
    },
    { 
        id:"m13", 
        slug:"death", 
        name_zh:"死神", 
        name_en:"Death",
        core_zh:"结束=重生的前提",
        core_en:"Ending = prerequisite for rebirth",
        upright: ["转化", "放下", "切割", "新阶段"],
        reversed: ["害怕改变", "执念", "慢性结束", "走不出"]
    },
    { 
        id:"m14", 
        slug:"temperance", 
        name_zh:"节制", 
        name_en:"Temperance",
        core_zh:"两极融合，找中间态",
        core_en:"Merge the poles, find the middle ground",
        upright: ["平衡", "疗愈", "整合", "适度"],
        reversed: ["极端", "失衡", "过度", "摩擦"]
    },
    { 
        id:"m15", 
        slug:"the-devil", 
        name_zh:"恶魔", 
        name_en:"The Devil",
        core_zh:"看见执念与上瘾，重新谈规则",
        core_en:"See obsessions and addictions, renegotiate the rules",
        upright: ["欲望", "依附", "诱惑", "阴影"],
        reversed: ["解脱", "戒断", "自由", "断链"]
    },
    { 
        id:"m16", 
        slug:"the-tower", 
        name_zh:"高塔", 
        name_en:"The Tower",
        core_zh:"虚假的会倒塌，之后重建真实",
        core_en:"The false will collapse, then rebuild the real",
        upright: ["崩塌", "真相显现", "震荡", "重置"],
        reversed: ["延迟爆发", "逃避真相", "脆弱重建", "否认"]
    },
    { 
        id:"m17", 
        slug:"the-star", 
        name_zh:"星星", 
        name_en:"The Star",
        core_zh:"跟随微光，信号会变强",
        core_en:"Follow the faint light, the signal will strengthen",
        upright: ["希望", "复原", "指引", "宁静"],
        reversed: ["怀疑", "能量枯竭", "迷失", "不信"]
    },
    { 
        id:"m18", 
        slug:"the-moon", 
        name_zh:"月亮", 
        name_en:"The Moon",
        core_zh:"不是所有感觉都是真相，要验证",
        core_en:"Not all feelings are truth, verify them",
        upright: ["幻象", "梦", "潜意识", "不确定"],
        reversed: ["清晰浮现", "恐惧消散", "真相露出", "过度脑补"]
    },
    { 
        id:"m19", 
        slug:"the-sun", 
        name_zh:"太阳", 
        name_en:"The Sun",
        core_zh:"允许被看见，但别燃尽",
        core_en:"Allow yourself to be seen, but don't burn out",
        upright: ["喜悦", "成功", "生命力", "真实"],
        reversed: ["过曝", "自大", "延迟", "疲惫"]
    },
    { 
        id:"m20", 
        slug:"judgement", 
        name_zh:"审判", 
        name_en:"Judgement",
        core_zh:"回应召唤，别再推迟自己",
        core_en:"Answer the call, stop postponing yourself",
        upright: ["觉醒", "评估", "重生", "召唤"],
        reversed: ["自我审判", "回避使命", "怀疑", "困在过去"]
    },
    { 
        id:"m21", 
        slug:"the-world", 
        name_zh:"世界", 
        name_en:"The World",
        core_zh:"闭环完成，然后升级",
        core_en:"Complete the cycle, then level up",
        upright: ["完成", "整合", "里程碑", "圆满"],
        reversed: ["差一点", "未完成", "尾巴", "延迟"]
    }
  ];
  