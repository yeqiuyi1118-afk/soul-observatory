/* ============================================
   SOUL OBSERVATORY - Main Script
   Immersive Long Page Portal with Full Interactions
   ============================================ */

// ============================================
// Configuration & Global State
// ============================================


window.CONFIG = window.CONFIG || {
    GEMINI_API_KEY: 'YOUR_GEMINI_API_KEY_HERE'
};

window.currentLang = 'en';
let isUpsideWorld = false;
let isDragging = false;
let isConsoleOpen = false;
let currentQuiz = null;
let currentQuizIndex = 0;
let quizAnswers = [];
let drawnCards = [];
let swipeStartX = 0;
let swipeStartY = 0;
let longPressTimer = null;

// ============================================
// i18n Dictionary
// ============================================

const i18n = {
    en: {
        'toggle-label': 'Surface / Shadow',
        'hero-kicker': 'An Archive for Self-Exploration',
        'hero-subtitle': 'Search credible tests. Meet your shadow. Generate a soul-page.',
        'hero-cta': 'Enter The Archives',
        'hero-coords': '44.3444° S, 131.0369° E',
        'archives-title': 'The Archives',
        'archives-desc': 'Curated directories from Ability Pivot Lab: MBTI, attachment, career, and more.',
        'trending-title': 'Editor Picks',
        'trending-desc': 'Handpicked tests for deeper exploration.',
        'quiz-title': 'The Quiz Lab',
        'quiz-desc': 'Built-in tests. Answer at your own pace.',
        'gallery-title': 'Results Gallery',
        'gallery-desc': 'Showcase of soul-pages and insights.',
        'card-room-title': 'The Card Room',
        'card-room-desc': 'Draw cards. Reveal patterns. Long-press for hidden layers.',
        'draw-1': 'Draw 1',
        'draw-3': 'Draw 3',
        'gesture-title': 'Gesture Playground',
        'gesture-desc': 'Try: Swipe left/right, Drag, Long-press.',
        'gesture-hint': 'Swipe, drag, or long-press me',
        'shadow-title': 'Shadow Sanctuary',
        'shadow-desc': 'The dark patterns. The uncomfortable truths. Only visible in the Upside Down.',
        'shadow-card-1': 'Shadow Index Results',
        'shadow-card-1-desc': 'Your archetype: Eleven, Maxine, or Pearl?',
        'about-title': 'About the Architect',
        'about-desc': 'This is a personal exploration portal. Built with curiosity and care.',
        'about-text': 'Soul Observatory is a curated archive of credible self-exploration tests, combined with AI-powered analysis and personalized soul-page generation. It\'s designed for those who seek deeper understanding—not diagnosis, but insight.',
        'about-text-2': 'Privacy-first. Session-only. For self-exploration—not medical advice.',
        'footer-text': 'Soul Observatory © 2025',
        'footer-disclaimer': 'For self-exploration & fun only. Not medical/professional advice.',
        'search-placeholder': 'Search test sites...',
        'search-btn': 'Search',
        'console-title': 'Miao Miao',
        'console-sub': 'Console',
        'console-fab': 'Console',
        'welcome-message': 'Welcome. I see you.',
        'quiz-start': 'Start',
        'quiz-next': 'Next',
        'quiz-back': 'Back',
        'quiz-submit': 'Submit',
        'quiz-progress': 'Question {current} of {total}'
    },
    zh: {
        'toggle-label': '表世界 / 里世界',
        'hero-kicker': '自我探索档案馆',
        'hero-subtitle': '搜索可信测试。遇见你的阴影。生成灵魂主页。',
        'hero-cta': '进入档案馆',
        'hero-coords': '44.3444° 南, 131.0369° 东',
        'archives-title': '档案馆',
        'archives-desc': '来自 Ability Pivot Lab 的精选目录：MBTI、依恋、职业等。',
        'trending-title': '编辑推荐',
        'trending-desc': '精选测试，深入探索。',
        'quiz-title': '测验实验室',
        'quiz-desc': '内置测试。按自己的节奏回答。',
        'gallery-title': '结果画廊',
        'gallery-desc': '灵魂主页和洞察展示。',
        'card-room-title': '卡牌室',
        'card-room-desc': '抽卡。揭示模式。长按显示隐藏层。',
        'draw-1': '抽 1 张',
        'draw-3': '抽 3 张',
        'gesture-title': '手势 playground',
        'gesture-desc': '试试：左右滑动、拖拽、长按。',
        'gesture-hint': '滑动、拖拽或长按我',
        'shadow-title': '暗面圣殿',
        'shadow-desc': '黑暗模式。不适真相。仅在颠倒世界可见。',
        'shadow-card-1': '阴影指数结果',
        'shadow-card-1-desc': '你的原型：Eleven、Maxine 还是 Pearl？',
        'about-title': '关于建筑师',
        'about-desc': '这是一个个人探索门户。用好奇和关怀构建。',
        'about-text': 'Soul Observatory 是一个精选的可信自我探索测试档案，结合 AI 驱动的分析和个性化灵魂主页生成。它专为寻求更深理解的人设计——不是诊断，而是洞察。',
        'about-text-2': '隐私优先。仅会话存储。用于自我探索——非医疗建议。',
        'footer-text': 'Soul Observatory © 2025',
        'footer-disclaimer': '仅用于自我探索与娱乐。非医疗/专业建议。',
        'search-placeholder': '搜索测试网站...',
        'search-btn': '搜索',
        'console-title': '喵喵',
        'console-sub': '控制台',
        'console-fab': '控制台',
        'welcome-message': '欢迎。我看到你了。',
        'quiz-start': '开始',
        'quiz-next': '下一题',
        'quiz-back': '上一题',
        'quiz-submit': '提交',
        'quiz-progress': '第 {current} 题，共 {total} 题'
    }
};

// ============================================
// Initialize on DOM Load
// ============================================

document.addEventListener('DOMContentLoaded', () => {
    initAuraEffect();
    initScrollReveal();
    initWheelSnap();
    initLanguageToggle();
    initWorldToggle();
    initConsole();
    initSearch();
    initQuizLab();
    initCardRoom();
    initGesturePlayground();
        initWaterDroplets();
        initBloodDrops();
        initVoiceSynthesis();
        initBokehLights();
        initFlashlightFocus();
        initClouds();
    initParallaxScroll();
    initCinematicVoid();
    initMotionBlur();
    renderArchives();
    renderTrending();
    renderQuizCards();
    updateTexts();
    
    // Initialize Miao Miao state
    if (typeof MiaoMiao !== 'undefined') {
        MiaoMiao.updateState('surface');
        updateMiaoMiaoMessage();
    }
});

// ============================================
// Aura Effect (Mouse Follow)
// ============================================

function initAuraEffect() {
    const auraBg = document.querySelector('.aura-background');
    if (!auraBg) return;
    
    document.addEventListener('mousemove', (e) => {
        const mx = (e.clientX / window.innerWidth) * 100;
        const my = (e.clientY / window.innerHeight) * 100;
        document.documentElement.style.setProperty('--mx', `${mx}%`);
        document.documentElement.style.setProperty('--my', `${my}%`);
    });
}

// ============================================
// Scroll Reveal (IntersectionObserver)
// ============================================

function initScrollReveal() {
    const reveals = document.querySelectorAll('.reveal');
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('is-in');
            }
        });
    }, {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    });
    
    reveals.forEach(reveal => observer.observe(reveal));
}

// ============================================
// Wheel Snap (Lightweight Section Jump)
// ============================================

function initWheelSnap() {
    const main = document.getElementById('mainScroll');
    if (!main) return;
    
    let isScrolling = false;
    let scrollTimeout = null;
    let lastWheelTime = 0;
    let wheelAccumulator = 0;
    
    main.addEventListener('wheel', (e) => {
        // 只在主世界启用，里世界使用正常滚动
        if (document.body.classList.contains('upside-world')) {
            return;
        }
        
        const now = Date.now();
        const timeSinceLastWheel = now - lastWheelTime;
        lastWheelTime = now;
        
        // 如果滚动正在进行，阻止新的滚动触发
        if (isScrolling) {
            e.preventDefault();
            return;
        }
        
        // 累积滚动量，避免小幅度滚动触发跳转
        wheelAccumulator += e.deltaY;
        
        // 如果滚动间隔太短，累积滚动量
        if (timeSinceLastWheel < 100) {
            // 继续累积，不触发跳转
            return;
        }
        
        // 检查累积的滚动量是否足够触发跳转
        const threshold = 80; // 提高阈值，避免过于敏感
        
        if (Math.abs(wheelAccumulator) > threshold) {
            isScrolling = true;
            e.preventDefault();
            
            const sections = document.querySelectorAll('.section');
            if (sections.length === 0) {
                isScrolling = false;
                wheelAccumulator = 0;
                return;
            }
            
            // 找到当前最接近视口顶部的 section
            let currentIndex = -1;
            let minDistance = Infinity;
            
            sections.forEach((section, index) => {
                const rect = section.getBoundingClientRect();
                const distance = Math.abs(rect.top);
                if (distance < minDistance && rect.top >= -100) {
                    minDistance = distance;
                    currentIndex = index;
                }
            });
            
            // 如果没找到，使用第一个可见的 section
            if (currentIndex === -1) {
                sections.forEach((section, index) => {
                    const rect = section.getBoundingClientRect();
                    if (rect.top < window.innerHeight && rect.bottom > 0) {
                        currentIndex = index;
                    }
                });
            }
            
            if (currentIndex === -1) currentIndex = 0;
            
            // 确定滚动方向
            const scrollDown = wheelAccumulator > 0;
            
            // 执行滚动
            let targetIndex = currentIndex;
            if (scrollDown && currentIndex < sections.length - 1) {
                targetIndex = currentIndex + 1;
            } else if (!scrollDown && currentIndex > 0) {
                targetIndex = currentIndex - 1;
            }
            
            if (targetIndex !== currentIndex) {
                sections[targetIndex].scrollIntoView({ 
                    behavior: 'smooth', 
                    block: 'start' 
                });
            }
            
            // 重置累积器
            wheelAccumulator = 0;
            
            // 设置滚动锁定时间
            clearTimeout(scrollTimeout);
            scrollTimeout = setTimeout(() => {
                isScrolling = false;
                wheelAccumulator = 0;
            }, 800); // 增加锁定时间，确保滚动完成
        } else {
            // 如果累积量不够，重置累积器（防止反向滚动累积）
            if (timeSinceLastWheel > 300) {
                wheelAccumulator = 0;
            }
        }
    }, { passive: false }); // 改为 false，因为我们需要 preventDefault
}

// ============================================
// Language Toggle
// ============================================

function initLanguageToggle() {
    const langToggle = document.getElementById('langToggle');
    if (!langToggle) return;
    
    langToggle.addEventListener('click', () => {
        langToggle.classList.add('interference');
        setTimeout(() => {
            window.currentLang = window.currentLang === 'en' ? 'zh' : 'en';
            updateTexts();
            renderArchives();
            renderTrending();
            renderQuizCards();
            if (currentQuiz) {
                renderQuiz();
            }
            updateMiaoMiaoMessage();
            langToggle.classList.remove('interference');
        }, 200);
    });
}

function updateTexts() {
    const texts = i18n[window.currentLang];
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (texts[key]) {
            el.textContent = texts[key];
        }
    });
    document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
        const key = el.getAttribute('data-i18n-placeholder');
        if (texts[key]) {
            el.placeholder = texts[key];
        }
    });
    // Update tarot modal if open
    updateTarotModalLanguage();
}

// ============================================
// World Toggle (Upside Down)
// ============================================

function initWorldToggle() {
    const toggle = document.getElementById('worldToggle');
    if (!toggle) return;
    
    toggle.addEventListener('click', (e) => {
        if (!isDragging) {
            toggleWorld();
        }
    });
    
    let startX = 0;
    let startLeft = false;
    
    toggle.addEventListener('mousedown', (e) => {
        isDragging = true;
        startX = e.clientX;
        startLeft = !toggle.classList.contains('active');
        e.preventDefault();
    });
    
    document.addEventListener('mousemove', (e) => {
        if (!isDragging) return;
        const deltaX = e.clientX - startX;
        const threshold = 30;
        
        if (startLeft && deltaX > threshold) {
            if (!toggle.classList.contains('active')) {
                toggleWorld();
            }
        } else if (!startLeft && deltaX < -threshold) {
            if (toggle.classList.contains('active')) {
                toggleWorld();
            }
        }
    });
    
    document.addEventListener('mouseup', () => {
        isDragging = false;
    });
}

function toggleWorld() {
    const toggle = document.getElementById('worldToggle');
    const body = document.body;
    
    const wasUpsideWorld = isUpsideWorld;
    isUpsideWorld = !isUpsideWorld;
    
    // Trigger symmetry-glitch effect
    body.classList.add('symmetry-glitch');
    setTimeout(() => {
        body.classList.remove('symmetry-glitch');
    }, 150);
    
    if (isUpsideWorld) {
        body.classList.remove('surface-world');
        body.classList.add('upside-world');
        toggle.classList.add('active');
        toggle.setAttribute('aria-checked', 'true');
    } else {
        body.classList.remove('upside-world');
        body.classList.add('surface-world');
        toggle.classList.remove('active');
        toggle.setAttribute('aria-checked', 'false');
    }
    
    // Update Miao Miao state
    if (typeof MiaoMiao !== 'undefined') {
        MiaoMiao.updateState(isUpsideWorld ? 'upside' : 'surface');
        updateMiaoMiaoMessage();
    }
}

// ============================================
// Console (Miao Miao)
// ============================================

let voiceEnabled = true;

function initConsole() {
    const consoleFrame = document.querySelector('.console-frame');
    const consoleFab = document.getElementById('consoleFab');
    const consoleMinBtn = document.getElementById('consoleMinBtn');
    const consoleCloseBtn = document.getElementById('consoleCloseBtn');
    const voiceToggleBtn = document.getElementById('voiceToggleBtn');
    
    if (!consoleFrame || !consoleFab) return;
    
    consoleFab.addEventListener('click', () => {
        openConsole();
    });
    
    if (consoleMinBtn) {
        consoleMinBtn.addEventListener('click', () => {
            closeConsole();
        });
    }
    
    if (consoleCloseBtn) {
        consoleCloseBtn.addEventListener('click', () => {
            closeConsole();
        });
    }
    
    if (voiceToggleBtn) {
        voiceToggleBtn.addEventListener('click', () => {
            voiceEnabled = !voiceEnabled;
            voiceToggleBtn.textContent = voiceEnabled ? '🔊' : '🔇';
            if (!voiceEnabled) {
                stopSpeaking();
            }
        });
    }
}

function openConsole() {
    const consoleFrame = document.querySelector('.console-frame');
    const consoleFab = document.getElementById('consoleFab');
    
    if (consoleFrame && consoleFab) {
        consoleFrame.classList.add('is-open');
        consoleFab.classList.add('is-hidden');
        isConsoleOpen = true;
    }
}

function closeConsole() {
    const consoleFrame = document.querySelector('.console-frame');
    const consoleFab = document.getElementById('consoleFab');
    
    if (consoleFrame && consoleFab) {
        consoleFrame.classList.remove('is-open');
        consoleFab.classList.remove('is-hidden');
        isConsoleOpen = false;
    }
}

function updateMiaoMiaoMessage() {
    const welcomeMessage = document.getElementById('welcomeMessage');
    if (welcomeMessage && typeof MiaoMiao !== 'undefined') {
        const greeting = MiaoMiao.getGreeting();
        welcomeMessage.textContent = greeting;
        // Speak greeting on first load
        if (!isConsoleOpen) {
            setTimeout(() => {
                speakMiaoMiaoResponse(greeting);
            }, 500);
        }
    }
}

// Trigger nosebleed effect
function triggerNosebleed() {
    const nosebleed = document.getElementById('consoleNosebleed');
    if (nosebleed) {
        nosebleed.classList.add('active');
        setTimeout(() => {
            nosebleed.classList.remove('active');
        }, 3000);
    }
}

// ============================================
// Search Functions
// ============================================

function initSearch() {
    const searchBtn = document.getElementById('searchBtn');
    const searchInput = document.getElementById('searchInput');
    
    if (!searchBtn || !searchInput) return;
    
    searchBtn.addEventListener('click', handleSearch);
    searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            handleSearch();
        }
    });
    
    // Real-time filtering
    searchInput.addEventListener('input', (e) => {
        const query = e.target.value.trim();
        if (query.length > 0) {
            filterArchives(query);
        } else {
            renderArchives();
        }
    });
}

function handleSearch() {
    const searchInput = document.getElementById('searchInput');
    const query = searchInput.value.trim();
    
    if (!query) return;
    
    const consoleOutput = document.getElementById('consoleOutput');
    if (!consoleOutput) return;
    
    addConsoleMessage(query, 'user');
    
    // Trigger Miao Miao thinking (nosebleed)
    triggerNosebleed();
    if (typeof MiaoMiao !== 'undefined') {
        const thinking = MiaoMiao.getThinking();
        addConsoleMessage(thinking, 'system');
        // Speak thinking indicator
        speakMiaoMiaoResponse(thinking);
    }
    
    // Search archives
    setTimeout(() => {
        const results = searchArchives(query);
        if (results.length > 0) {
            results.forEach(result => {
                const msg = document.createElement('div');
                msg.className = 'message system';
                const lang = window.currentLang;
                const name = lang === 'zh' ? result.nameZH : result.nameEN;
                msg.innerHTML = `<a href="${result.url}" target="_blank" style="color: inherit; text-decoration: underline;">${name}</a> [${result.langTag}] ${result.type}`;
                consoleOutput.appendChild(msg);
            });
            
            // Miao Miao response
            if (typeof MiaoMiao !== 'undefined') {
                const response = MiaoMiao.generateResponse({
                    observation: true,
                    nextAction: true
                });
                addConsoleMessage(response, 'system');
                // Speak the response
                speakMiaoMiaoResponse(response);
                // Trigger aura shake in upside world
                if (isUpsideWorld) {
                    triggerAuraShake();
                }
            }
        } else {
            addConsoleMessage('No results found.', 'system');
        }
    }, 500);
    
    searchInput.value = '';
}

function filterArchives(query) {
    const archivesCards = document.getElementById('archivesCards');
    if (!archivesCards) return;
    
    const results = searchArchives(query);
    archivesCards.innerHTML = '';
    
    results.forEach(result => {
        const card = createArchiveCard(result);
        archivesCards.appendChild(card);
    });
}

function searchArchives(query) {
    if (typeof archivesData === 'undefined') return [];
    
    const allLinks = [];
    archivesData.forEach(category => {
        category.links.forEach(link => {
            allLinks.push({
                ...link,
                categoryEN: category.categoryEN,
                categoryZH: category.categoryZH
            });
        });
    });
    
    const lowerQuery = query.toLowerCase();
    return allLinks.filter(link => {
        return link.nameEN.toLowerCase().includes(lowerQuery) ||
               link.nameZH.toLowerCase().includes(lowerQuery) ||
               link.categoryEN.toLowerCase().includes(lowerQuery) ||
               link.categoryZH.toLowerCase().includes(lowerQuery) ||
               link.type.toLowerCase().includes(lowerQuery);
    });
}

function addConsoleMessage(text, type = 'system') {
    const consoleOutput = document.getElementById('consoleOutput');
    if (!consoleOutput) return null;
    
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${type}`;
    messageDiv.textContent = text;
    consoleOutput.appendChild(messageDiv);
    consoleOutput.scrollTop = consoleOutput.scrollHeight;
    return messageDiv;
}

// ============================================
// Render Archives
// ============================================

function renderArchives() {
    const archivesCards = document.getElementById('archivesCards');
    if (!archivesCards || typeof archivesData === 'undefined') return;
    
    archivesCards.innerHTML = '';
    
    let cardIndex = 0;
    archivesData.forEach(category => {
        category.links.forEach(link => {
            const card = createArchiveCard(link, category);
            // 为里世界卡片设置索引，用于动态定位
            if (document.body.classList.contains('upside-world')) {
                card.style.setProperty('--card-index', cardIndex);
            }
            archivesCards.appendChild(card);
            cardIndex++;
        });
    });
    
    // Re-observe for scroll reveal
    setTimeout(() => {
        const newReveals = archivesCards.querySelectorAll('.reveal');
        newReveals.forEach(reveal => {
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('is-in');
                    }
                });
            }, { threshold: 0.1 });
            observer.observe(reveal);
        });
    }, 100);
}

function createArchiveCard(link, category = null) {
    const card = document.createElement('a');
    card.className = 'card reveal';
    card.href = link.url;
    card.target = '_blank';
    card.rel = 'noreferrer';
    
    const lang = window.currentLang;
    const categoryName = category ? (lang === 'zh' ? category.categoryZH : category.categoryEN) : '';
    const linkName = lang === 'zh' ? link.nameZH : link.nameEN;
    
    card.innerHTML = `
        <div class="card-title">${categoryName || linkName}</div>
        <div class="card-desc">${linkName}</div>
        <div class="card-meta">[${link.langTag}] ${link.type}</div>
    `;
    
    return card;
}

// ============================================
// Render Trending
// ============================================

function renderTrending() {
    const trendingCards = document.getElementById('trendingCards');
    if (!trendingCards || typeof archivesData === 'undefined') return;
    
    // Pick first 3 links from first 3 categories as trending
    trendingCards.innerHTML = '';
    const picked = [];
    
    archivesData.slice(0, 3).forEach(category => {
        if (category.links.length > 0) {
            picked.push(category.links[0]);
        }
    });
    
    picked.forEach(link => {
        const card = createArchiveCard(link);
        card.classList.add('stage-frame'); // Add stage-frame effect
        trendingCards.appendChild(card);
    });
}

// ============================================
// Quiz Lab
// ============================================

function initQuizLab() {
    // Quiz cards are rendered, click handlers added in renderQuizCards
}

function renderQuizCards() {
    const quizCards = document.getElementById('quizCards');
    if (!quizCards || typeof internalQuizzes === 'undefined') return;
    
    quizCards.innerHTML = '';
    
    internalQuizzes.forEach(quiz => {
        const card = document.createElement('div');
        card.className = 'card reveal';
        card.style.cursor = 'pointer';
        
        const lang = window.currentLang;
        const title = lang === 'zh' ? quiz.titleZH : quiz.titleEN;
        const desc = lang === 'zh' ? quiz.descZH : quiz.descEN;
        
        card.innerHTML = `
            <div class="card-title">${title}</div>
            <div class="card-desc">${desc}</div>
        `;
        
        card.addEventListener('click', () => {
            startQuiz(quiz);
        });
        
        quizCards.appendChild(card);
    });
}

function startQuiz(quiz) {
    currentQuiz = quiz;
    currentQuizIndex = 0;
    quizAnswers = [];
    
    const quizContainer = document.getElementById('quizContainer');
    const quizCards = document.getElementById('quizCards');
    
    if (quizContainer && quizCards) {
        quizCards.style.display = 'none';
        quizContainer.style.display = 'block';
        renderQuiz();
    }
    
    // Trigger Miao Miao thinking
    triggerNosebleed();
    if (typeof MiaoMiao !== 'undefined') {
        const thinking = MiaoMiao.getThinking();
        addConsoleMessage(thinking, 'system');
        // Speak thinking indicator
        speakMiaoMiaoResponse(thinking);
    }
}

function renderQuiz() {
    const quizContainer = document.getElementById('quizContainer');
    if (!quizContainer || !currentQuiz) return;
    
    const lang = window.currentLang;
    const questions = currentQuiz.questions[lang];
    const question = questions[currentQuizIndex];
    const total = questions.length;
    const current = currentQuizIndex + 1;
    
    const progressText = i18n[lang]['quiz-progress']
        .replace('{current}', current)
        .replace('{total}', total);
    
    const selectedAnswer = quizAnswers[currentQuizIndex] || null;
    
    quizContainer.innerHTML = `
        <div class="quiz-progress">${progressText}</div>
        <div class="quiz-question">
            <div class="quiz-question-text">${question}</div>
            <div class="quiz-options">
                ${[1, 2, 3, 4, 5].map(score => `
                    <button class="quiz-option ${selectedAnswer === score ? 'selected' : ''}" 
                            data-score="${score}">
                        ${score} - ${getScoreLabel(score, lang)}
                    </button>
                `).join('')}
            </div>
        </div>
        <div class="quiz-controls">
            <button class="quiz-btn" id="quizBackBtn" ${currentQuizIndex === 0 ? 'disabled' : ''}>
                ${i18n[lang]['quiz-back']}
            </button>
            <button class="quiz-btn" id="quizNextBtn" ${currentQuizIndex === total - 1 ? 'style="display:none;"' : ''}>
                ${i18n[lang]['quiz-next']}
            </button>
            <button class="quiz-btn" id="quizSubmitBtn" ${currentQuizIndex !== total - 1 ? 'style="display:none;"' : ''}>
                ${i18n[lang]['quiz-submit']}
            </button>
        </div>
    `;
    
    // Add event listeners
    document.querySelectorAll('.quiz-option').forEach(option => {
        option.addEventListener('click', (e) => {
            document.querySelectorAll('.quiz-option').forEach(opt => opt.classList.remove('selected'));
            e.target.classList.add('selected');
            const score = parseInt(e.target.dataset.score);
            quizAnswers[currentQuizIndex] = score;
        });
    });
    
    document.getElementById('quizBackBtn')?.addEventListener('click', () => {
        if (currentQuizIndex > 0) {
            currentQuizIndex--;
            renderQuiz();
        }
    });
    
    document.getElementById('quizNextBtn')?.addEventListener('click', () => {
        if (quizAnswers[currentQuizIndex]) {
            currentQuizIndex++;
            renderQuiz();
        }
    });
    
    document.getElementById('quizSubmitBtn')?.addEventListener('click', () => {
        if (quizAnswers[currentQuizIndex]) {
            submitQuiz();
        }
    });
    
    // Keyboard navigation
    document.addEventListener('keydown', handleQuizKeyboard);
}

function handleQuizKeyboard(e) {
    if (!currentQuiz) return;
    
    if (e.key === 'ArrowLeft' && currentQuizIndex > 0) {
        currentQuizIndex--;
        renderQuiz();
    } else if (e.key === 'ArrowRight') {
        if (currentQuizIndex < currentQuiz.questions[window.currentLang].length - 1) {
            if (quizAnswers[currentQuizIndex]) {
                currentQuizIndex++;
                renderQuiz();
            }
        } else if (quizAnswers[currentQuizIndex]) {
            submitQuiz();
        }
    }
}

function getScoreLabel(score, lang) {
    const labels = {
        en: ['Strongly Disagree', 'Disagree', 'Neutral', 'Agree', 'Strongly Agree'],
        zh: ['强烈不同意', '不同意', '中性', '同意', '强烈同意']
    };
    return labels[lang][score - 1];
}

function submitQuiz() {
    if (!currentQuiz) return;
    
    const totalScore = quizAnswers.reduce((sum, score) => sum + score, 0);
    const result = currentQuiz.results.find(r => 
        totalScore >= r.scoreRange[0] && totalScore <= r.scoreRange[1]
    ) || currentQuiz.results[0];
    
    const lang = window.currentLang;
    const resultCard = document.createElement('div');
    resultCard.className = 'card stage-frame';
    resultCard.innerHTML = `
        <div class="card-title">${result.nameEN} / ${result.nameZH}</div>
        <div class="card-desc">${lang === 'zh' ? result.insightZH : result.insightEN}</div>
        <div class="card-meta">Score: ${totalScore}</div>
        <div style="margin-top: 1rem; font-size: 0.9rem;">
            ${lang === 'zh' ? result.nextStepZH : result.nextStepEN}
        </div>
    `;
    
    const galleryGrid = document.getElementById('galleryGrid');
    if (galleryGrid) {
        galleryGrid.appendChild(resultCard);
        resultCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
    
    // Reset quiz
    const quizContainer = document.getElementById('quizContainer');
    const quizCards = document.getElementById('quizCards');
    if (quizContainer && quizCards) {
        quizContainer.style.display = 'none';
        quizCards.style.display = 'grid';
    }
    
    currentQuiz = null;
    currentQuizIndex = 0;
    quizAnswers = [];
    
    // Trigger Miao Miao achievement
    if (typeof MiaoMiao !== 'undefined') {
        MiaoMiao.triggerAchievement('quizCompleted');
        if (totalScore >= 100) {
            MiaoMiao.triggerAchievement('highScore');
        }
        updateMiaoMiaoMessage();
        // Trigger aura shake in upside world
        if (isUpsideWorld) {
            triggerAuraShake();
        }
    }
    
    // Remove keyboard listener
    document.removeEventListener('keydown', handleQuizKeyboard);
}

// ============================================
// Card Room
// ============================================

function initCardRoom() {
    // Card room initialization is now handled by tarot-render.js
    // The draw1 and draw3 buttons are bound in the tarot rendering code
}

function drawCards(count) {
    const cardRoomArea = document.getElementById('cardRoomArea');
    if (!cardRoomArea) return;
    
    const cardTexts = [
        'Pattern', 'Shadow', 'Boundary', 'Signal', 'Mirror', 'Spotlight',
        'Control', 'Distance', 'Recognition', 'Protection', 'Autonomy', 'Belonging'
    ];
    
    for (let i = 0; i < count; i++) {
        const card = document.createElement('div');
        card.className = 'drawn-card';
        const text = cardTexts[Math.floor(Math.random() * cardTexts.length)];
        
        card.innerHTML = `
            <div class="drawn-card-front">${text}</div>
            <div class="drawn-card-back">?</div>
            <div class="drawn-card-hidden">Hidden layer: ${text} reveals deeper patterns.</div>
        `;
        
        // Flip animation
        setTimeout(() => {
            card.classList.add('flipped');
        }, i * 200);
        
        // Drag functionality
        initCardDrag(card);
        
        // Long press for hidden layer
        initCardLongPress(card);
        
        cardRoomArea.appendChild(card);
        drawnCards.push(card);
    }
    
    // Trigger rare card achievement (random)
    if (Math.random() > 0.7 && typeof MiaoMiao !== 'undefined') {
        MiaoMiao.triggerAchievement('rareCard');
        updateMiaoMiaoMessage();
    }
}

function initCardDrag(card) {
    let isDragging = false;
    let startX, startY, offsetX, offsetY;
    
    card.addEventListener('mousedown', (e) => {
        isDragging = true;
        card.classList.add('dragging');
        startX = e.clientX;
        startY = e.clientY;
        const rect = card.getBoundingClientRect();
        offsetX = e.clientX - rect.left;
        offsetY = e.clientY - rect.top;
        e.preventDefault();
    });
    
    document.addEventListener('mousemove', (e) => {
        if (!isDragging) return;
        card.style.position = 'fixed';
        card.style.left = (e.clientX - offsetX) + 'px';
        card.style.top = (e.clientY - offsetY) + 'px';
        card.style.zIndex = '1000';
    });
    
    document.addEventListener('mouseup', () => {
        if (isDragging) {
            isDragging = false;
            card.classList.remove('dragging');
            card.style.position = '';
            card.style.left = '';
            card.style.top = '';
            card.style.zIndex = '';
            // Spring back animation
            card.style.transition = 'transform 0.3s ease';
            setTimeout(() => {
                card.style.transition = '';
            }, 300);
        }
    });
}

function initCardLongPress(card) {
    let pressTimer = null;
    
    card.addEventListener('mousedown', () => {
        pressTimer = setTimeout(() => {
            card.classList.add('show-hidden');
        }, 400);
    });
    
    card.addEventListener('mouseup', () => {
        clearTimeout(pressTimer);
    });
    
    card.addEventListener('mouseleave', () => {
        clearTimeout(pressTimer);
        card.classList.remove('show-hidden');
    });
}

// ============================================
// Gesture Playground
// ============================================

function initGesturePlayground() {
    const gestureCard = document.getElementById('gestureCard');
    if (!gestureCard) return;
    
    // Swipe detection
    let startX = 0;
    let startY = 0;
    
    gestureCard.addEventListener('touchstart', (e) => {
        startX = e.touches[0].clientX;
        startY = e.touches[0].clientY;
    });
    
    gestureCard.addEventListener('touchend', (e) => {
        const endX = e.changedTouches[0].clientX;
        const endY = e.changedTouches[0].clientY;
        const deltaX = endX - startX;
        const deltaY = endY - startY;
        
        if (Math.abs(deltaX) > Math.abs(deltaY) && Math.abs(deltaX) > 60) {
            if (deltaX > 0) {
                gestureCard.textContent = 'Swiped Right!';
            } else {
                gestureCard.textContent = 'Swiped Left!';
            }
            setTimeout(() => {
                const lang = window.currentLang;
                gestureCard.textContent = i18n[lang]['gesture-hint'];
            }, 2000);
        }
    });
    
    // Drag (already handled by card drag)
    initCardDrag(gestureCard);
    
    // Long press
    initCardLongPress(gestureCard);
}

// ============================================
// Water Droplets Effect (Car Window Style)
// ============================================

function initWaterDroplets() {
    const dropletsContainer = document.getElementById('waterDroplets');
    if (!dropletsContainer) return;
    
    // Create initial droplets
    createDroplets(20);
    
    // Continuously add new droplets
    setInterval(() => {
        createDroplets(3);
    }, 2000);
}

function createDroplets(count) {
    const dropletsContainer = document.getElementById('waterDroplets');
    if (!dropletsContainer) return;
    
    for (let i = 0; i < count; i++) {
        const droplet = document.createElement('div');
        droplet.className = 'droplet';
        
        // Random size
        const size = Math.random();
        if (size > 0.7) {
            droplet.classList.add('droplet-large');
        } else if (size < 0.3) {
            droplet.classList.add('droplet-small');
        }
        
        // Random speed
        const speed = Math.random();
        if (speed > 0.7) {
            droplet.classList.add('droplet-fast');
        } else if (speed < 0.3) {
            droplet.classList.add('droplet-slow');
        }
        
        // Random position
        droplet.style.left = Math.random() * 100 + '%';
        droplet.style.animationDelay = Math.random() * 2 + 's';
        droplet.style.animationDuration = (6 + Math.random() * 9) + 's';
        
        dropletsContainer.appendChild(droplet);
        
        // Remove after animation
        setTimeout(() => {
            if (droplet.parentNode) {
                droplet.parentNode.removeChild(droplet);
            }
        }, 20000);
    }
}

// ============================================
// Blood Drops Effect (里世界血滴)
// ============================================

function initBloodDrops() {
    const bloodDropsContainer = document.getElementById('bloodDrops');
    if (!bloodDropsContainer) return;
    
    // 只在里世界显示
    if (!document.body.classList.contains('upside-world')) {
        bloodDropsContainer.style.opacity = '0';
        return;
    }
    
    const dropSizes = ['small', 'medium', 'large', 'extra-large'];
    const dropSpeeds = ['fast', 'normal', 'slow'];
    
    const createBloodDrop = () => {
        const drop = document.createElement('div');
        drop.className = 'blood-drop';
        
        // 随机大小
        const size = dropSizes[Math.floor(Math.random() * dropSizes.length)];
        drop.classList.add(`blood-drop-${size}`);
        
        // 随机速度
        if (Math.random() < 0.3) {
            const speed = dropSpeeds[Math.floor(Math.random() * dropSpeeds.length)];
            if (speed !== 'normal') {
                drop.classList.add(`blood-drop-${speed}`);
            }
        }
        
        // 随机水平位置
        drop.style.left = Math.random() * 100 + 'vw';
        
        // 随机延迟
        drop.style.animationDelay = Math.random() * 2 + 's';
        
        // 随机透明度
        const opacity = 0.6 + Math.random() * 0.3; // 0.6 到 0.9
        drop.style.opacity = opacity;
        
        bloodDropsContainer.appendChild(drop);
        
        // 血滴落下后移除，并创建新的
        drop.addEventListener('animationend', () => {
            drop.remove();
            // 随机间隔后创建新血滴
            setTimeout(() => {
                if (document.body.classList.contains('upside-world')) {
                    createBloodDrop();
                }
            }, Math.random() * 3000 + 1000); // 1-4秒后
        });
    };
    
    // 初始生成血滴
    for (let i = 0; i < 15; i++) {
        setTimeout(() => {
            if (document.body.classList.contains('upside-world')) {
                createBloodDrop();
            }
        }, i * 500); // 错开生成时间
    }
    
    // 监听世界切换
    const observer = new MutationObserver(() => {
        if (document.body.classList.contains('upside-world')) {
            bloodDropsContainer.style.opacity = '1';
            // 如果容器为空，重新生成
            if (bloodDropsContainer.children.length === 0) {
                for (let i = 0; i < 15; i++) {
                    setTimeout(() => {
                        if (document.body.classList.contains('upside-world')) {
                            createBloodDrop();
                        }
                    }, i * 500);
                }
            }
        } else {
            bloodDropsContainer.style.opacity = '0';
            // 清空血滴
            bloodDropsContainer.innerHTML = '';
        }
    });
    
    observer.observe(document.body, {
        attributes: true,
        attributeFilter: ['class']
    });
}

// ============================================
// Voice Synthesis (AI Speech)
// ============================================

let speechSynthesis = null;
let currentVoice = null;
let isSpeaking = false;

function initVoiceSynthesis() {
    if ('speechSynthesis' in window) {
        speechSynthesis = window.speechSynthesis;
        
        // Wait for voices to load
        if (speechSynthesis.getVoices().length === 0) {
            speechSynthesis.addEventListener('voiceschanged', () => {
                selectVoice();
            });
        } else {
            selectVoice();
        }
    } else {
        console.warn('Speech synthesis not supported');
    }
}

function selectVoice() {
    if (!speechSynthesis) return;
    
    const voices = speechSynthesis.getVoices();
    const lang = window.currentLang === 'zh' ? 'zh' : 'en';
    
    // Try to find a matching voice
    currentVoice = voices.find(voice => 
        voice.lang.startsWith(lang)
    ) || voices.find(voice => 
        voice.lang.startsWith('en')
    ) || voices[0];
}

function speakText(text, options = {}) {
    if (!speechSynthesis || !currentVoice || isSpeaking) return;
    
    // Stop any current speech
    speechSynthesis.cancel();
    
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.voice = currentVoice;
    utterance.rate = options.rate || 0.9;
    utterance.pitch = options.pitch || 1.0;
    utterance.volume = options.volume || 0.8;
    utterance.lang = window.currentLang === 'zh' ? 'zh-CN' : 'en-US';
    
    utterance.onstart = () => {
        isSpeaking = true;
        triggerNosebleed(); // Visual indicator
    };
    
    utterance.onend = () => {
        isSpeaking = false;
    };
    
    utterance.onerror = (error) => {
        console.error('Speech synthesis error:', error);
        isSpeaking = false;
    };
    
    speechSynthesis.speak(utterance);
}

function stopSpeaking() {
    if (speechSynthesis && isSpeaking) {
        speechSynthesis.cancel();
        isSpeaking = false;
    }
}

// Speak Miao Miao responses
function speakMiaoMiaoResponse(text) {
    if (!voiceEnabled) return;
    
    if (typeof MiaoMiao !== 'undefined') {
        const mode = MiaoMiao.state.mode;
        const options = {
            rate: mode === 'eleven' ? 0.85 : mode === 'maxine' ? 0.95 : 0.8,
            pitch: mode === 'eleven' ? 1.0 : mode === 'maxine' ? 1.1 : 0.9,
            volume: 0.7
        };
        speakText(text, options);
    } else {
        speakText(text);
    }
}

// ============================================
// Bokeh Lights Effect (Upside World)
// ============================================

function initBokehLights() {
    const bokehContainer = document.getElementById('bokehLights');
    if (!bokehContainer) return;
    
    // Create bokeh lights
    const colors = [
        'rgba(255, 255, 255, 0.2)',
        'rgba(255, 200, 100, 0.25)',
        'rgba(255, 180, 50, 0.3)',
        'rgba(200, 200, 220, 0.2)',
        'rgba(150, 150, 200, 0.15)',
        'rgba(255, 140, 0, 0.25)'
    ];
    
    for (let i = 0; i < 12; i++) {
        const light = document.createElement('div');
        light.className = 'bokeh-light';
        
        const size = 100 + Math.random() * 200;
        light.style.width = size + 'px';
        light.style.height = size + 'px';
        light.style.background = colors[Math.floor(Math.random() * colors.length)];
        light.style.left = Math.random() * 100 + '%';
        light.style.top = Math.random() * 100 + '%';
        light.style.animationDelay = Math.random() * 20 + 's';
        light.style.animationDuration = (15 + Math.random() * 10) + 's';
        
        bokehContainer.appendChild(light);
    }
}

// ============================================
// Flashlight Focus Effect (手电筒对焦)
// ============================================

function initFlashlightFocus() {
    const flashlight = document.getElementById('flashlightFocus');
    const mistImage = document.getElementById('mistImage');
    if (!flashlight || !mistImage) return;
    
    let isActive = false;
    const clearRadius = 250;
    
    document.addEventListener('mousemove', (e) => {
        if (!isActive) {
            flashlight.classList.add('active');
            isActive = true;
        }
        
        const x = e.clientX;
        const y = e.clientY;
        
        // Update flashlight position
        flashlight.style.left = x + 'px';
        flashlight.style.top = y + 'px';
        
        // Calculate distance from center for blur gradient
        const rect = mistImage.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        const distX = x - centerX;
        const distY = y - centerY;
        const distance = Math.sqrt(distX * distX + distY * distY);
        
        // Create mask for clear zone (inverse of flashlight shadow)
        const maskGradient = `radial-gradient(circle ${clearRadius}px at ${x - rect.left}px ${y - rect.top}px, 
            black 0%, 
            black ${clearRadius * 0.7}px, 
            transparent ${clearRadius * 0.9}px)`;
        
        mistImage.style.maskImage = maskGradient;
        mistImage.style.webkitMaskImage = maskGradient;
        mistImage.style.maskComposite = 'subtract';
        mistImage.style.webkitMaskComposite = 'subtract';
    });
    
    document.addEventListener('mouseleave', () => {
        flashlight.classList.remove('active');
        isActive = false;
        mistImage.style.maskImage = 'none';
        mistImage.style.webkitMaskImage = 'none';
    });
}

// ============================================
// Clouds Generation (表世界云朵)
// ============================================

function initClouds() {
    const cloudsContainer = document.getElementById('cloudsContainer');
    if (!cloudsContainer) return;
    
    // 只在表世界显示
    if (!document.body.classList.contains('surface-world')) {
        cloudsContainer.style.opacity = '0';
        return;
    }
    
    const cloudSizes = ['small', 'medium', 'large', 'extra-large'];
    const cloudLayers = [1, 2, 3, 4, 5, 6];
    const numClouds = 12; // 生成12朵云
    
    // 清空容器
    cloudsContainer.innerHTML = '';
    
    for (let i = 0; i < numClouds; i++) {
        const cloud = document.createElement('div');
        cloud.className = 'cloud';
        
        // 随机大小
        const size = cloudSizes[Math.floor(Math.random() * cloudSizes.length)];
        cloud.classList.add(`cloud-${size}`);
        
        // 随机层级（高度）
        const layer = cloudLayers[Math.floor(Math.random() * cloudLayers.length)];
        cloud.classList.add(`cloud-layer-${layer}`);
        
        // 随机起始位置（左侧）
        const startX = Math.random() * -300 - 200; // -500 到 -200
        const startY = Math.random() * 100 - 50; // -50 到 50
        cloud.style.left = `${startX}px`;
        cloud.style.transform = `translateY(${startY}px)`;
        
        // 随机延迟，让云朵错开出现
        const delay = Math.random() * 30;
        cloud.style.animationDelay = `-${delay}s`;
        
        // 随机透明度变化
        const opacity = 0.5 + Math.random() * 0.3; // 0.5 到 0.8
        cloud.style.opacity = opacity;
        
        cloudsContainer.appendChild(cloud);
    }
    
    // 监听世界切换
    const observer = new MutationObserver(() => {
        if (document.body.classList.contains('surface-world')) {
            cloudsContainer.style.opacity = '1';
            // 如果容器为空，重新生成
            if (cloudsContainer.children.length === 0) {
                initClouds();
            }
        } else {
            cloudsContainer.style.opacity = '0';
        }
    });
    
    observer.observe(document.body, {
        attributes: true,
        attributeFilter: ['class']
    });
}

// ============================================
// Parallax Scroll Effect
// ============================================

function initParallaxScroll() {
    const mistImage = document.getElementById('mistImage');
    const heroInner = document.querySelector('.hero-inner');
    if (!mistImage) return;
    
    let lastScrollY = 0;
    let ticking = false;
    
    function updateParallax() {
        const scrollY = window.scrollY || document.documentElement.scrollTop;
        const scrollProgress = scrollY / window.innerHeight;
        
        // Background moves slowly (parallax)
        const bgOffset = scrollY * 0.3;
        mistImage.style.transform = `translateY(${bgOffset}px)`;
        
        // Text moves faster (upward float)
        if (heroInner) {
            const textOffset = scrollY * 1.2;
            heroInner.style.transform = `translateY(${textOffset}px)`;
        }
        
        ticking = false;
    }
    
    window.addEventListener('scroll', () => {
        if (!ticking) {
        window.requestAnimationFrame(updateParallax);
        ticking = true;
    }
}, { passive: true });
}

// ============================================
// Cinematic Void Aura Animation (GSAP)
// ============================================

function initCinematicVoid() {
    if (typeof gsap === 'undefined') return;
    
    const auraOrange = document.getElementById('auraOrange');
    const auraCyan = document.getElementById('auraCyan');
    const auraOrange2 = document.getElementById('auraOrange2');
    
    if (!auraOrange || !auraCyan || !auraOrange2) return;
    
    // Continuous floating animation
    gsap.to(auraOrange, {
        x: '+=100',
        y: '+=50',
        duration: 8,
        repeat: -1,
        yoyo: true,
        ease: 'sine.inOut'
    });
    
    gsap.to(auraCyan, {
        x: '-=80',
        y: '-=60',
        duration: 10,
        repeat: -1,
        yoyo: true,
        ease: 'sine.inOut',
        delay: 2
    });
    
    gsap.to(auraOrange2, {
        x: '+=60',
        y: '+=80',
        duration: 12,
        repeat: -1,
        yoyo: true,
        ease: 'sine.inOut',
        delay: 4
    });
    
    // Mouse follow effect (subtle)
    document.addEventListener('mousemove', (e) => {
        if (!document.body.classList.contains('upside-world')) return;
        
        const mx = (e.clientX / window.innerWidth - 0.5) * 200;
        const my = (e.clientY / window.innerHeight - 0.5) * 200;
        
        gsap.to(auraOrange, {
            x: `+=${mx * 0.3}`,
            y: `+=${my * 0.3}`,
            duration: 2,
            ease: 'power2.out'
        });
        
        gsap.to(auraCyan, {
            x: `+=${mx * 0.2}`,
            y: `+=${my * 0.2}`,
            duration: 2.5,
            ease: 'power2.out'
        });
    });
}

// ============================================
// Motion Blur Effect (Ghost Trail)
// ============================================

let lastMouseX = 0;
let lastMouseY = 0;
let mouseVelocity = 0;
let lastTime = Date.now();

function initMotionBlur() {
    const motionBlurOverlay = document.getElementById('motionBlurOverlay');
    if (!motionBlurOverlay) return;
    
    document.addEventListener('mousemove', (e) => {
        if (!document.body.classList.contains('upside-world')) return;
        
        const now = Date.now();
        const deltaTime = now - lastTime;
        lastTime = now;
        
        const deltaX = e.clientX - lastMouseX;
        const deltaY = e.clientY - lastMouseY;
        const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
        mouseVelocity = distance / deltaTime;
        
        lastMouseX = e.clientX;
        lastMouseY = e.clientY;
        
        // Activate motion blur on fast movement
        if (mouseVelocity > 0.5) {
            motionBlurOverlay.classList.add('active');
            motionBlurOverlay.style.setProperty('--mx', e.clientX + 'px');
            motionBlurOverlay.style.setProperty('--my', e.clientY + 'px');
            
            setTimeout(() => {
                motionBlurOverlay.classList.remove('active');
            }, 200);
        }
    });
    
    // Scroll-based motion blur
    let lastScrollY = window.scrollY;
    let scrollVelocity = 0;
    
    window.addEventListener('scroll', () => {
        if (!document.body.classList.contains('upside-world')) return;
        
        const now = Date.now();
        const deltaTime = now - lastTime;
        const deltaY = Math.abs(window.scrollY - lastScrollY);
        scrollVelocity = deltaY / deltaTime;
        
        lastScrollY = window.scrollY;
        
        if (scrollVelocity > 0.3) {
            motionBlurOverlay.classList.add('active');
            motionBlurOverlay.style.setProperty('--mx', '50%');
            motionBlurOverlay.style.setProperty('--my', '50%');
            
            setTimeout(() => {
                motionBlurOverlay.classList.remove('active');
            }, 300);
        }
    }, { passive: true });
    
    // Apply motion blur to cards and text on fast movement
    if (typeof gsap !== 'undefined') {
        const cards = document.querySelectorAll('.card');
        const titles = document.querySelectorAll('.section-title, .hero-title');
        
        document.addEventListener('mousemove', (e) => {
            if (!document.body.classList.contains('upside-world')) return;
            if (mouseVelocity < 0.3) return;
            
            cards.forEach((card, index) => {
                const rect = card.getBoundingClientRect();
                const cardCenterX = rect.left + rect.width / 2;
                const cardCenterY = rect.top + rect.height / 2;
                const distX = e.clientX - cardCenterX;
                const distY = e.clientY - cardCenterY;
                const distance = Math.sqrt(distX * distX + distY * distY);
                
                if (distance < 300) {
                    const blurAmount = Math.min(10, (300 - distance) / 30);
                    const offsetX = distX * 0.1;
                    const offsetY = distY * 0.1;
                    
                    gsap.to(card, {
                        filter: `blur(${blurAmount}px)`,
                        x: offsetX,
                        y: offsetY,
                        duration: 0.3,
                        ease: 'power2.out'
                    });
                    
                    setTimeout(() => {
                        gsap.to(card, {
                            filter: 'blur(0px)',
                            x: 0,
                            y: 0,
                            duration: 0.5,
                            ease: 'power2.out'
                        });
                    }, 100);
                }
            });
            
            titles.forEach(title => {
                if (mouseVelocity > 0.5) {
                    gsap.to(title, {
                        filter: `blur(${Math.min(5, mouseVelocity * 2)}px)`,
                        x: (e.clientX - window.innerWidth / 2) * 0.05,
                        y: (e.clientY - window.innerHeight / 2) * 0.05,
                        duration: 0.2,
                        ease: 'power2.out'
                    });
                    
                    setTimeout(() => {
                        gsap.to(title, {
                            filter: 'blur(0px)',
                            x: 0,
                            y: 0,
                            duration: 0.4,
                            ease: 'power2.out'
                        });
                    }, 150);
                }
            });
        });
    }
}

// ============================================
// Aura Shake & Light Diffusion (On Result Generation)
// ============================================

function triggerAuraShake() {
    const cinematicVoid = document.getElementById('cinematicVoid');
    if (!cinematicVoid || !document.body.classList.contains('upside-world')) return;
    
    cinematicVoid.classList.add('shaking');
    
    setTimeout(() => {
        cinematicVoid.classList.remove('shaking');
        cinematicVoid.classList.add('diffusing');
        
        setTimeout(() => {
            cinematicVoid.classList.remove('diffusing');
        }, 2000);
    }, 500);
}
function getMode() {
    return document.body.classList.contains("upside-world") ? "upside" : "surface";
  }
  
  function drawUnique(n) {
    const pool = [...window.TAROT];
    const out = [];
    for (let i = 0; i < n; i++) {
      const idx = Math.floor(Math.random() * pool.length);
      const card = pool.splice(idx, 1)[0];
      card.reversed = Math.random() < 0.35;
      out.push(card);
    }
    return out;
  }
  
  function resetSlot(slotEl) {
    slotEl.classList.add("is-empty");
    const img = slotEl.querySelector(".tarot-img");
    const label = slotEl.querySelector(".tarot-label");
    if (img) { img.style.display = "none"; img.removeAttribute("src"); }
    if (label) label.textContent = "";
  }
  
  // Store drawn cards data - cache to window for global access
  window.currentTarotSlots = [null, null, null, null];
  const drawnCardsData = new Map();
  
  function renderToSlots(cards) {
    const mode = getMode();
    
    // Reset cache
    window.currentTarotSlots = [null, null, null, null];
    
    // First, reset all slots
    for (let i = 0; i < 4; i++) {
      const slot = document.querySelector(`[data-slot="${i}"]`);
      if (slot) {
        resetSlot(slot);
        slot.classList.add('card-back');
        slot.classList.remove('card-revealed');
        slot.classList.remove('showing-details');
        // Remove old event listeners by cloning
        const newSlot = slot.cloneNode(true);
        slot.parentNode.replaceChild(newSlot, slot);
      }
    }
    
    // Then render cards (face down initially)
    for (let i = 0; i < cards.length && i < 4; i++) {
      const slot = document.querySelector(`[data-slot="${i}"]`);
      if (!slot) continue;
  
      const card = cards[i];
      const img = slot.querySelector(".tarot-img");
      const label = slot.querySelector(".tarot-label");
      const qmark = slot.querySelector(".qmark");
      
      // Store card data in both Map and window cache
      drawnCardsData.set(slot, card);
      window.currentTarotSlots[i] = card;
      
      // Show card back (face down)
      slot.classList.remove("is-empty");
      slot.classList.add("card-back");
      slot.classList.add("has-card");
      
      if (qmark) {
        qmark.textContent = "🂠";
        qmark.style.display = "block";
      }
      if (img) {
        img.style.display = "none";
      }
      if (label) {
        label.textContent = "";
      }
      
      // Add click handler to reveal card (first click) or show meaning (if revealed)
      slot.addEventListener('click', function handleSlotClick(e) {
        // If already revealed, show meaning modal
        if (slot.classList.contains('card-revealed')) {
          e.stopPropagation();
          showCardMeaningModal(i);
          return;
        }
        
        // Otherwise, reveal the card
        const cardData = drawnCardsData.get(slot);
        if (!cardData) return;
        
        const url = window.renderCardPNG(cardData, mode);
        
        slot.classList.remove("card-back");
        slot.classList.add("card-revealed");
        
        if (qmark) qmark.style.display = "none";
        if (img) {
          img.src = url;
          img.style.display = "block";
          img.style.opacity = "0";
          setTimeout(() => {
            img.style.transition = "opacity 0.5s ease";
            img.style.opacity = "1";
          }, 10);
        }
        if (label) {
          label.textContent = `${cardData.name_zh}（${cardData.reversed ? "逆位" : "正位"}）`;
          label.style.opacity = "0";
          setTimeout(() => {
            label.style.transition = "opacity 0.5s ease";
            label.style.opacity = "1";
          }, 10);
        }
        
        // Add flip animation
        slot.style.transform = "scale(0.95)";
        setTimeout(() => {
          slot.style.transition = "transform 0.3s ease";
          slot.style.transform = "scale(1)";
        }, 50);
      }, { once: false });
    }
  }
  
  // Show card meaning modal
  function showCardMeaningModal(slotIndex) {
    const card = window.currentTarotSlots[slotIndex];
    if (!card) return;
    
    const lang = window.currentLang || 'en';
    
    // Create or get modal
    let modal = document.getElementById('tarot-meaning-modal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'tarot-meaning-modal';
      modal.className = 'tarot-meaning-modal';
      document.body.appendChild(modal);
    }
    
    // Store current slot index for language update
    modal.setAttribute('data-current-slot', slotIndex);
    
    // Get card data
    const cardName = lang === 'zh' ? card.name_zh : card.name_en;
    const cardCore = lang === 'zh' ? (card.core_zh || '') : (card.core_en || '');
    const keywords = card.reversed ? (card.reversed || []) : (card.upright || []);
    const position = card.reversed ? (lang === 'zh' ? '逆位' : 'Reversed') : (lang === 'zh' ? '正位' : 'Upright');
    
    // Build modal content
    modal.innerHTML = `
      <div class="tarot-modal-overlay"></div>
      <div class="tarot-modal-content">
        <button class="tarot-modal-close" aria-label="Close">×</button>
        <div class="tarot-modal-header">
          <h2 class="tarot-modal-title">${cardName}</h2>
          <span class="tarot-modal-position">${position}</span>
        </div>
        <div class="tarot-modal-core">
          <p>${cardCore}</p>
        </div>
        <div class="tarot-modal-keywords">
          <div class="tarot-keywords-label">${lang === 'zh' ? '关键词' : 'Keywords'}</div>
          <div class="tarot-keywords-tags">
            ${keywords.map(kw => `<span class="tarot-keyword-tag">${kw}</span>`).join('')}
          </div>
        </div>
      </div>
    `;
    
    // Show modal
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
    
    // Close handlers
    const overlay = modal.querySelector('.tarot-modal-overlay');
    const closeBtn = modal.querySelector('.tarot-modal-close');
    
    function closeModal() {
      modal.classList.remove('active');
      document.body.style.overflow = '';
    }
    
    // Remove old listeners and add new ones
    const newOverlay = modal.querySelector('.tarot-modal-overlay');
    const newCloseBtn = modal.querySelector('.tarot-modal-close');
    
    newOverlay.addEventListener('click', closeModal);
    newCloseBtn.addEventListener('click', closeModal);
    
    // ESC key to close
    const escHandler = (e) => {
      if (e.key === 'Escape' && modal.classList.contains('active')) {
        closeModal();
        document.removeEventListener('keydown', escHandler);
      }
    };
    document.addEventListener('keydown', escHandler);
  }
  
  // Update modal content when language changes
  function updateTarotModalLanguage() {
    const modal = document.getElementById('tarot-meaning-modal');
    if (!modal || !modal.classList.contains('active')) return;
    
    // Find which slot is currently showing by checking modal's data attribute
    const currentSlotIndex = modal.getAttribute('data-current-slot');
    if (currentSlotIndex === null) return;
    
    const slotIndex = parseInt(currentSlotIndex);
    if (isNaN(slotIndex)) return;
    
    // Re-render modal with new language
    showCardMeaningModal(slotIndex);
  }
  
  // 绑定按钮（点击才抽卡）
  document.getElementById("draw1")?.addEventListener("click", () => {
    const cards = drawUnique(1);
    renderToSlots(cards);
  });
  
  document.getElementById("draw3")?.addEventListener("click", () => {
    const cards = drawUnique(3);
    renderToSlots(cards);
  });
  