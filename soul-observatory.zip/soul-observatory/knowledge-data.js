// Knowledge Data extracted from knowledge.md

// Test Website Directory
const testWebsites = {
    en: [
        { name: 'OpenPsychometrics', url: 'https://openpsychometrics.org/', tags: ['EN', 'Free', 'Serious'] },
        { name: 'Truity', url: 'https://www.truity.com/', tags: ['EN', 'Mix', 'Report'] },
        { name: 'Psychology Today Tests', url: 'https://www.psychologytoday.com/us/tests', tags: ['EN', 'Mix'] },
        { name: '16Personalities', url: 'https://www.16personalities.com/', tags: ['EN/ZH', 'Free'] },
        { name: '16Personalities 简中', url: 'https://www.16personalities.com/ch', tags: ['ZH'] },
        { name: 'OpenPsychometrics Big Five', url: 'https://openpsychometrics.org/tests/IPIP-BFFM/', tags: ['EN', 'Free'] },
        { name: 'BigFive-Test', url: 'https://bigfive-test.com/en', tags: ['EN', 'Free'] },
        { name: 'Personality Assessor (IPIP-300)', url: 'https://www.personalityassessor.com/ipip300/', tags: ['EN', 'Free'] },
        { name: 'IPIP Official', url: 'https://ipip.ori.org/', tags: ['EN', 'Research'] },
        { name: 'HEXACO official', url: 'https://hexaco.org/', tags: ['EN'] },
        { name: 'IDR Labs HEXACO', url: 'https://www.idrlabs.com/hexaco/test.php', tags: ['EN', 'Commercial'] },
        { name: 'Truity Enneagram', url: 'https://www.truity.com/test/enneagram-personality-test', tags: ['EN'] },
        { name: 'Enneagram Universe', url: 'https://enneagramuniverse.com/', tags: ['EN'] },
        { name: 'Attachment Project', url: 'https://www.attachmentproject.com/attachment-style-quiz/', tags: ['EN'] },
        { name: '5 Love Languages', url: 'https://5lovelanguages.com/quizzes/love-language', tags: ['EN'] },
        { name: 'O*NET Interest Profiler', url: 'https://onetinterestprofiler.org/', tags: ['EN', 'Official'] },
        { name: 'OpenPsychometrics RIASEC', url: 'https://openpsychometrics.org/tests/RIASEC/', tags: ['EN', 'Free'] },
        { name: '123test Career', url: 'https://www.123test.com/career-test/', tags: ['EN'] },
        { name: 'VIA Character Strengths', url: 'https://www.viacharacter.org/', tags: ['EN'] },
        { name: 'MHA Screening', url: 'https://screening.mhanational.org/', tags: ['EN', 'Screening'] }
    ],
    zh: [
        { name: '壹心理测试', url: 'https://www.xinli001.com/ceshi', tags: ['ZH', 'Mix'] },
        { name: '测测 Cece', url: 'https://www.cece.com/', tags: ['ZH', 'Fun'] },
        { name: '知我探索', url: 'https://www.zhiwotansuo.cn/', tags: ['ZH', 'Mix'] },
        { name: '壹点灵', url: 'https://www.ydl.com/', tags: ['ZH', 'Mix'] },
        { name: '16Personalities', url: 'https://www.16personalities.com/', tags: ['EN/ZH', 'Free'] },
        { name: '16Personalities 简中', url: 'https://www.16personalities.com/ch', tags: ['ZH'] }
    ]
};

// Shadow Index Questions (24 items)
const shadowIndexQuestions = {
    en: [
        'I prefer controlling the pace rather than being pushed by random events.',
        'When things go wrong, I suppress feelings first and calculate the next move.',
        'I label people in my head, even if I never say it out loud.',
        'I\'d rather be disliked than underestimated.',
        'I quickly sense what others want, then decide whether to give it.',
        'I use silence/cold distance to show dissatisfaction sometimes.',
        'I\'m sensitive to "fairness," but I know I can be biased too.',
        'I keep a little mystery to stay interesting.',
        'I dislike owing people; I prefer "clean accounts" in relationships.',
        'I treat softness as a risk, so I lean rational.',
        'I care about face/appearance more than I admit.',
        'I rehearse worst-case scenarios to avoid losing.',
        'I trust rules more than people.',
        'I can endure short-term pain for long-term wins.',
        'I sometimes test people in relationships.',
        'I dodge being seen through jokes or topic shifts.',
        'I\'m extremely sensitive to being controlled.',
        'I\'m strict with others\' mistakes; even harsher with mine.',
        'I hide vulnerability because it feels like weakness.',
        'I use logic to "win" even when comfort is needed.',
        'I can feel strong protectiveness/possessiveness toward my people.',
        'I sometimes push myself because of comparison or jealousy.',
        'Being needed makes me feel safe.',
        'I keep an inner ledger of who deserves my energy.'
    ],
    zh: [
        '我更喜欢控制节奏，而不是被随机事件推着走。',
        '当事情出错时，我先压抑情绪，然后计算下一步。',
        '我会在心里给人贴标签，即使我从不说出来。',
        '我宁愿被讨厌，也不愿被低估。',
        '我能快速感知别人的需求，然后决定是否满足。',
        '我有时用沉默/冷距离来表达不满。',
        '我对"公平"很敏感，但我知道我也可能有偏见。',
        '我保持一点神秘感来保持有趣。',
        '我不喜欢欠人情；在关系中我更喜欢"账目清晰"。',
        '我把柔软视为风险，所以我倾向于理性。',
        '我比承认的更在乎面子/外表。',
        '我预演最坏情况以避免失败。',
        '我信任规则胜过信任人。',
        '我可以忍受短期痛苦以换取长期胜利。',
        '我有时会在关系中测试别人。',
        '我通过玩笑或转移话题来躲避被看穿。',
        '我对被控制极其敏感。',
        '我对别人的错误很严格；对自己的更严格。',
        '我隐藏脆弱，因为它让我感觉像弱点。',
        '即使需要安慰时，我也用逻辑来"获胜"。',
        '我对属于我的人有强烈的保护欲/占有欲。',
        '我有时会因为比较或嫉妒而逼迫自己。',
        '被需要让我感到安全。',
        '我内心有一本账，记录谁值得我的能量。'
    ]
};

// Character Archetypes
const characterArchetypes = {
    eleven: {
        name: { en: 'The Signal (Eleven)', zh: '信号 (Eleven)' },
        core: { en: 'safety + belonging + autonomy', zh: '安全 + 归属 + 自主' },
        pattern: { en: 'low-language/high-action; shutdown ↔ explosive protection', zh: '低语言/高行动；关闭 ↔ 爆发性保护' },
        strength: { en: 'loyalty, intuition, fast learning when safe', zh: '忠诚、直觉、在安全时快速学习' },
        shadow: { en: 'self-worth tied to usefulness/power; betrayal/abandonment triggers', zh: '自我价值与有用性/力量绑定；背叛/遗弃触发' },
        visual: { en: 'signal/VHS, lab vs home, "other side" void', zh: '信号/VHS，实验室 vs 家，"另一面"虚空' }
    },
    maxine: {
        name: { en: 'The Spotlight (Maxine)', zh: '聚光灯 (Maxine)' },
        core: { en: 'recognition + self-made identity', zh: '认可 + 自我塑造的身份' },
        pattern: { en: 'confident performance; strategic charm; reads the room', zh: '自信的表演；战略性魅力；读懂房间' },
        strength: { en: 'ambition, grit, bold risk-taking', zh: '野心、坚韧、大胆冒险' },
        shadow: { en: 'validation hunger; moral flexibility; compartmentalization', zh: '验证渴望；道德灵活性；分隔' },
        visual: { en: 'spotlight/stage, bold headlines, poster vibe', zh: '聚光灯/舞台，大胆标题，海报氛围' }
    },
    pearl: {
        name: { en: 'The Mirror (Pearl)', zh: '镜子 (Pearl)' },
        core: { en: 'be seen/chosen; escape "smallness"', zh: '被看见/被选择；逃离"渺小"' },
        pattern: { en: 'sweet fantasy ↔ envy/shame spiral under rejection', zh: '甜蜜幻想 ↔ 拒绝下的嫉妒/羞耻螺旋' },
        strength: { en: 'imagination, emotional force, persistence', zh: '想象力、情感力量、坚持' },
        shadow: { en: 'jealousy/possessiveness; rejection intolerance', zh: '嫉妒/占有欲；拒绝不耐受' },
        visual: { en: 'vintage pastoral + unsettling stillness; mirror; subtle glitch', zh: '复古田园 + 不安的静止；镜子；微妙故障' }
    }
};

// Mapping logic: Shadow Index score ranges and MBTI patterns
// Shadow Index: 24-120 (higher = more shadow traits)
// Eleven: protective, boundary-driven, intuitive (lower shadow, high intuition)
// Maxine: ambitious, self-directed, performance-aware (moderate shadow, high agency)
// Pearl: recognition-hungry, imaginative, comparison-sensitive (higher shadow, high sensitivity)

function determineArchetype(shadowScore, mbtiType) {
    // Shadow score ranges (24-120)
    // Low: 24-56, Medium: 57-88, High: 89-120
    
    // MBTI patterns
    const intuitiveTypes = ['INTJ', 'INTP', 'ENTJ', 'ENTP', 'INFJ', 'INFP', 'ENFJ', 'ENFP'];
    const sensingTypes = ['ISTJ', 'ISFJ', 'ESTJ', 'ESFJ', 'ISTP', 'ISFP', 'ESTP', 'ESFP'];
    
    const isIntuitive = intuitiveTypes.includes(mbtiType?.toUpperCase());
    const isSensing = sensingTypes.includes(mbtiType?.toUpperCase());
    
    // Decision logic
    if (shadowScore <= 56) {
        // Low shadow - likely Eleven (protective, boundary-driven)
        return 'eleven';
    } else if (shadowScore >= 89) {
        // High shadow - likely Pearl (recognition-hungry, comparison-sensitive)
        return 'pearl';
    } else {
        // Medium shadow - check MBTI
        if (isIntuitive && shadowScore <= 72) {
            return 'eleven';
        } else if (isSensing || shadowScore >= 73) {
            return 'maxine';
        } else {
            return 'maxine'; // Default to Maxine for medium range
        }
    }
}
