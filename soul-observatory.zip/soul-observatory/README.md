# Soul Observatory

一个极简但高级的单页面网站，结合了复古美学和 AI 驱动的性格分析。

## 功能特性

### 视觉设计
- **表世界（默认）**：复古奶油色背景 (#F4F1EA)，森林绿文字，优雅衬线字体，极细网格背景
- **里世界**：暗黑背景，荧光绿网格，文字红色 Glitch 撕裂特效
- **80 年代复古监视器窗口**：中央显示搜索和预览功能
- **小 11 对话区域**：右下角显示 AI 对话

### 交互功能
- **物理拨杆切换**：右上角红色拨杆，支持鼠标拖拽切换表里世界
- **语言切换**：左上角 [中 / EN] 按钮，0.2 秒信号干扰动效后切换所有文字
- **AI 性格分析**：基于 MBTI 或星座的深度解读
- **HTML 预览**：AI 生成的个性化 HTML 代码实时预览

## 设置说明

### 1. 配置 Google Gemini API

1. 访问 [Google AI Studio](https://makersuite.google.com/app/apikey) 获取 API 密钥
2. 复制 `config.js.example` 文件为 `config.js`：
   ```bash
   cp config.js.example config.js
   ```
3. 打开 `config.js` 文件，将 `YOUR_GEMINI_API_KEY_HERE` 替换为你的实际 API 密钥：

```javascript
const CONFIG = {
    GEMINI_API_KEY: 'your-actual-api-key-here'
};
```

### 2. 运行网站

直接在浏览器中打开 `index.html` 文件即可。

或者使用本地服务器：

```bash
# 使用 Python
python -m http.server 8000

# 使用 Node.js (需要安装 http-server)
npx http-server

# 然后访问 http://localhost:8000
```

## 使用说明

1. **切换世界**：点击或拖拽右上角的红色拨杆，在表世界和里世界之间切换
2. **切换语言**：点击左上角的语言按钮，在中英文之间切换
3. **输入性格类型**：在监视器窗口的搜索框中输入你的 MBTI（如：INTJ, ENFP）或星座（如：天蝎座, Scorpio）
4. **查看分析**：点击"分析"按钮，小 11 会在右下角对话区域给出性格解读
5. **查看预览**：AI 生成的 HTML 代码会在监视器窗口的预览区域显示

### 表世界 vs 里世界

- **表世界**：提供平衡、积极的性格分析
- **里世界**：聚焦阴暗面、隐藏缺陷和不适真相（S 倾向）

## 技术栈

- HTML5
- CSS3 (Grid, Flexbox, Animations)
- Vanilla JavaScript (ES6+)
- Google Gemini API

## 浏览器支持

支持所有现代浏览器（Chrome, Firefox, Safari, Edge）。

## 注意事项

- 需要有效的 Google Gemini API 密钥才能使用 AI 功能
- API 调用会产生费用，请查看 Google 的定价信息
- 建议在本地开发环境中测试，避免暴露 API 密钥
