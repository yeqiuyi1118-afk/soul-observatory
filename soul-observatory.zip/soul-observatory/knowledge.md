# Knowledge Consolidation — Soul Observatory / Ability Pivot Lab
> Default language: EN (toggle: EN | 中文)
> Use-case: Build 3-page MVP (Explore / Create / Play) + content library for quizzes.

---

## 0) MVP Snapshot
**Working name:** Soul Observatory / TestHub / Ability Pivot Lab  
**One-liner:** A centralized portal that aggregates credible self-exploration tests, plus AI-generated quizzes and mini test games.

**3-page MVP**
1) **Explore (Home):** categories + trending tests + search  
2) **Create (AI Test Forge):** generate a new quiz (topic/tone/length) + preview  
3) **Play (Arcade Zone):** mini games (card draw / this-or-that / 30-sec / spin wheel)

**Global UX notes**
- Dark neon / VHS scanlines / “signal” aesthetics (Stranger Things-inspired)
- Strong disclaimer + privacy microcopy
- Default EN, optional 中文 UI copy

**Disclaimer**
- For self-exploration & fun only. Not medical/professional advice.
- Privacy-first: do not store answers by default (session only).

---

## 1) Personal Exploration — Working Personality Model (EN summary)
> Source: your personal analysis report (AI version, 2025).  
> Goal: turn self-knowledge into “mechanisms” you can design for.

### 1.1 Core identity
You are best modeled as a **high-sensitivity + high-curiosity system** with strong life force.
Your inner theme is not “brokenness,” but **a sensitive nervous system that learned survival automation under pressure**, and is now learning to re-train itself with tools.

### 1.2 Family & early relationship shaping (high-level)
- A mixed environment where **warmth and pressure co-exist** shaped your “alertness” and performance sensitivity.
- A sibling relationship (especially younger brother) functions as a **stable attachment anchor** in your inner narrative.

### 1.3 Emotional–behavior chains (your “default programs”)
**Chain A: Task → Delay → Anxiety → Self-blame → Short sprint / shutdown**
- Procrastination is not laziness; it’s a **protection system**.

**Chain B: Long pressure → Somatic symptoms → Keep pushing → Collapse → Reboot**
- Your body tends to become the “alarm system”: tension, fatigue, sleep disruption, and forced resets.

**Chain C: Social message → Pressure → Avoid replying → Guilt → More avoidance**
- Not responding is often about **stress + perfection pressure**, not lack of care.

**Insight:** These chains are “one engine, different skins.”  
They share two drivers: **shame defense + nervous-system overload**.

### 1.4 Executive function model (why procrastination happens)
- **Shame defense:** “If I try my best and fail, it proves I’m not good enough.”  
  → Delay keeps a psychological escape route: “I didn’t really try.”
- **Overload defense:** starting triggers anxiety + bodily tension → attention collapses → seek quick relief  
  → short-term relief, long-term self-blame.

### 1.5 Intimacy & relationship script (approach–retreat)
- You want deep being-seen and secure choosing.
- But you also fear being exposed and rejected, so you may use:
  - **narrative control** (curating a story-self)
  - **distance strategies** (ambiguity / leaving first / not fully investing)
- This fits a **mixed anxious–avoidant pattern**, intensified by sensitivity.

### 1.6 Power/Boundary theme (consent-first, product-safe wording)
Your report also highlights a **power/structure fantasy tendency** that is less about “harm” and more about:
- testing safety and trust (“Will you stay if I show intensity?”)
- reversing helplessness into agency (fantasy control)
- breaking a “cold armor” to reach intimacy, then offering comfort/aftercare

**Important boundary note:** real-life safety boundaries are clear; the intensity is primarily **fantasy/atmosphere** and should be framed in products as **consent, clear limits, and aftercare**.

### 1.7 Existential drive
A strong theme is: **fear of death, but even more fear of not truly living.**
You tend to move environments to:
- escape constriction/shame
- search for a system that fits your sensitivity/curiosity
- test boundaries of growth (“How far can I go and still thrive?”)

### 1.8 Strengths (usable “assets”)
- High insight + narrative intelligence (can model yourself precisely)
- Curiosity-driven learning (deep focus when interest is active)
- Resilience (reboot ability)
- Cross-domain creativity (psychology + data + design + story)

### 1.9 Watch-outs (design constraints)
- quick-relief coping loops (scrolling / sleep chaos)
- pushing-until-collapse cycles
- shame-based avoidance of visibility (posting/performing only when perfect)
- intimacy protection that becomes loneliness (curation → distance)

**Design translation for your site**
- Use: “mechanism-based results” + “next-step navigation”
- Avoid: clinical claims, diagnosis tone, storing sensitive inputs

---

## 2) Test Website Directory (Core, expandable)
> Tags: [EN] [ZH] [Free] [Paid] [Serious] [Fun] [Report]

### 2.1 Collections / Libraries
- OpenPsychometrics — [EN][Free][Serious] https://openpsychometrics.org/
- Truity — [EN][Mix][Report] https://www.truity.com/
- Psychology Today Tests — [EN][Mix] https://www.psychologytoday.com/us/tests

### 2.2 Chinese ecosystems
- 壹心理测试 — [ZH][Mix] https://www.xinli001.com/ceshi
- 测测 Cece — [ZH][Fun] https://www.cece.com/
- 知我探索 — [ZH][Mix] https://www.zhiwotansuo.cn/
- 壹点灵 — [ZH][Mix] https://www.ydl.com/

### 2.3 MBTI / 16 types
- 16Personalities — [EN/ZH][Free] https://www.16personalities.com/
- 16Personalities 简中 — [ZH] https://www.16personalities.com/ch

### 2.4 Big Five / IPIP
- OpenPsychometrics Big Five — [EN][Free] https://openpsychometrics.org/tests/IPIP-BFFM/
- BigFive-Test — [EN][Free] https://bigfive-test.com/en
- Personality Assessor (IPIP-300) — [EN][Free] https://www.personalityassessor.com/ipip300/
- IPIP Official — [EN][Research] https://ipip.ori.org/

### 2.5 HEXACO
- HEXACO official — [EN] https://hexaco.org/
- IDR Labs HEXACO — [EN][Commercial] https://www.idrlabs.com/hexaco/test.php

### 2.6 Enneagram
- Truity Enneagram — [EN] https://www.truity.com/test/enneagram-personality-test
- Enneagram Universe — [EN] https://enneagramuniverse.com/

### 2.7 Attachment / Relationship
- Attachment Project — [EN] https://www.attachmentproject.com/attachment-style-quiz/
- 5 Love Languages — [EN] https://5lovelanguages.com/quizzes/love-language

### 2.8 Career / Interests (RIASEC etc.)
- O*NET Interest Profiler — [EN][Official] https://onetinterestprofiler.org/
- OpenPsychometrics RIASEC — [EN] https://openpsychometrics.org/tests/RIASEC/
- 123test Career — [EN] https://www.123test.com/career-test/

### 2.9 Strengths
- VIA Character Strengths — [EN] https://www.viacharacter.org/

### 2.10 Mental health screening (needs strong disclaimer)
- MHA Screening — [EN][Screening] https://screening.mhanational.org/

---

## 3) Shadow Index — 24 items (self-reflection)
**Scale (1–5):** 1=Strongly disagree … 5=Strongly agree  
**Positioning:** shadow tendencies for reflection, not diagnosis.

1. I prefer controlling the pace rather than being pushed by random events.  
2. When things go wrong, I suppress feelings first and calculate the next move.  
3. I label people in my head, even if I never say it out loud.  
4. I’d rather be disliked than underestimated.  
5. I quickly sense what others want, then decide whether to give it.  
6. I use silence/cold distance to show dissatisfaction sometimes.  
7. I’m sensitive to “fairness,” but I know I can be biased too.  
8. I keep a little mystery to stay interesting.  
9. I dislike owing people; I prefer “clean accounts” in relationships.  
10. I treat softness as a risk, so I lean rational.  
11. I care about face/appearance more than I admit.  
12. I rehearse worst-case scenarios to avoid losing.  
13. I trust rules more than people.  
14. I can endure short-term pain for long-term wins.  
15. I sometimes test people in relationships.  
16. I dodge being seen through jokes or topic shifts.  
17. I’m extremely sensitive to being controlled.  
18. I’m strict with others’ mistakes; even harsher with mine.  
19. I hide vulnerability because it feels like weakness.  
20. I use logic to “win” even when comfort is needed.  
21. I can feel strong protectiveness/possessiveness toward my people.  
22. I sometimes push myself because of comparison or jealousy.  
23. Being needed makes me feel safe.  
24. I keep an inner ledger of who deserves my energy.

**Scoring:** total 24–120 (optional subscales: Control / Distance / Comparison / Accounting / Boundary sensitivity)

---

## 4) Power & Boundaries — 12 items (consent-first, non-explicit)
**Scale (1–5)**  
**Positioning:** preference & communication style, not behavior instruction.

1. I feel safer when roles/rules are clear.  
2. I like agreeing on boundaries in advance (yes/no/maybe).  
3. I’m curious about power dynamics only if it’s safe and consensual.  
4. I prefer predictable intensity rather than surprises.  
5. I value a clear pause/stop system.  
6. I prefer talking through misunderstandings over cold distance.  
7. I want my pace respected, not rushed.  
8. Aftercare/closure matters to me (check-in, reassurance).  
9. I’m sensitive to shame, so I need gentleness and control.  
10. I’m attracted to people who are firm but respectful.  
11. Exploration is OK; being pushed is not.  
12. My core safety is: I can say “no” anytime and be taken seriously.

---

## 5) Character Models (spoiler-light, for quiz archetypes)
### 5.1 Eleven (Stranger Things)
- Core: safety + belonging + autonomy  
- Pattern: low-language/high-action; shutdown ↔ explosive protection  
- Strength: loyalty, intuition, fast learning when safe  
- Shadow: self-worth tied to usefulness/power; betrayal/abandonment triggers  
- Visual: signal/VHS, lab vs home, “other side” void

### 5.2 Maxine (X)
- Core: recognition + self-made identity  
- Pattern: confident performance; strategic charm; reads the room  
- Strength: ambition, grit, bold risk-taking  
- Shadow: validation hunger; moral flexibility; compartmentalization  
- Visual: spotlight/stage, bold headlines, poster vibe

### 5.3 Pearl (Pearl)
- Core: be seen/chosen; escape “smallness”  
- Pattern: sweet fantasy ↔ envy/shame spiral under rejection  
- Strength: imagination, emotional force, persistence  
- Shadow: jealousy/possessiveness; rejection intolerance  
- Visual: vintage pastoral + unsettling stillness; mirror; subtle glitch

**Archetype mapping for results**
- The Signal (Eleven-leaning): protective, boundary-driven, intuitive  
- The Spotlight (Maxine-leaning): ambitious, self-directed, performance-aware  
- The Mirror (Pearl-leaning): recognition-hungry, imaginative, comparison-sensitive

---

## 6) Play Page — Mini test game ideas
- Card Draw (3 cards) → “current pattern” result
- This-or-That → quick tendency label
- 30-second quiz → instinct frequency type
- Spin the wheel → random test/archetype
- “Perfect cards with hidden glitch” (Pearl vibe)

---

## 7) AI Test Forge — Prompt Templates (EN + 中文)
### EN
You are a creative quiz designer. Create a short self-reflection quiz (NOT medical advice).
- Topic: {topic}
- Tone: {tone} (neon-sci-fi / gentle / funny / serious)
- Length: {10 or 20}
Output:
1) Title
2) Questions
3) 3–5 result archetypes (name + 3 bullet insights)
4) One next-step suggestion per archetype
5) Disclaimer: “For self-exploration only.”

### 中文
你是一个有创意的测验设计师。生成一份“自我探索”小测（不是诊断，不是医疗建议）。
- 主题：{主题}
- 语气：{语气}（霓虹科幻/温柔/搞笑/严肃）
- 题量：{10或20}
输出：
1) 标题
2) 题目
3) 3–5种结果类型（命名+每种3条洞察）
4) 每种一个“下一步建议”
5) 免责声明：仅用于自我探索与娱乐

---
