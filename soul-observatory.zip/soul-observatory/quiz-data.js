// Internal Quizzes Data
// Structure: title/description (EN/ZH), questions (EN/ZH), results (archetypes with insights)

const internalQuizzes = [
    {
        id: 'shadow-index',
        titleEN: 'Shadow Index',
        titleZH: '阴影指数',
        descEN: '24 questions. Self-reflection on shadow tendencies. Not diagnosis—insight.',
        descZH: '24 题。对阴影倾向的自我反思。不是诊断——是洞察。',
        questions: {
            en: [
                'I prefer controlling the pace rather than being pushed by random events.',
                'When things go wrong, I suppress feelings first and calculate the next move.',
                'I label people in my head, even if I never say it out loud.',
                'I\'d rather be disliked than underestimated.',
                'I quickly sense what others want, then decide whether to give it.',
                'I use silence/cold distance to show dissatisfaction sometimes.',
                'I\'m sensitive to "fairness," but I know I can be biased too.',
                'I keep a little mystery to stay interesting.',
                'I dislike owing people; I prefer "clean accounts" in relationships.',
                'I treat softness as a risk, so I lean rational.',
                'I care about face/appearance more than I admit.',
                'I rehearse worst-case scenarios to avoid losing.',
                'I trust rules more than people.',
                'I can endure short-term pain for long-term wins.',
                'I sometimes test people in relationships.',
                'I dodge being seen through jokes or topic shifts.',
                'I\'m extremely sensitive to being controlled.',
                'I\'m strict with others\' mistakes; even harsher with mine.',
                'I hide vulnerability because it feels like weakness.',
                'I use logic to "win" even when comfort is needed.',
                'I can feel strong protectiveness/possessiveness toward my people.',
                'I sometimes push myself because of comparison or jealousy.',
                'Being needed makes me feel safe.',
                'I keep an inner ledger of who deserves my energy.'
            ],
            zh: [
                '我更喜欢控制节奏，而不是被随机事件推着走。',
                '当事情出错时，我先压抑情绪，然后计算下一步。',
                '我会在心里给人贴标签，即使我从不说出来。',
                '我宁愿被讨厌，也不愿被低估。',
                '我能快速感知别人的需求，然后决定是否满足。',
                '我有时用沉默/冷距离来表达不满。',
                '我对"公平"很敏感，但我知道我也可能有偏见。',
                '我保持一点神秘感来保持有趣。',
                '我不喜欢欠人情；在关系中我更喜欢"账目清晰"。',
                '我把柔软视为风险，所以我倾向于理性。',
                '我比承认的更在乎面子/外表。',
                '我预演最坏情况以避免失败。',
                '我信任规则胜过信任人。',
                '我可以忍受短期痛苦以换取长期胜利。',
                '我有时会在关系中测试别人。',
                '我通过玩笑或转移话题来躲避被看穿。',
                '我对被控制极其敏感。',
                '我对别人的错误很严格；对自己的更严格。',
                '我隐藏脆弱，因为它让我感觉像弱点。',
                '即使需要安慰时，我也用逻辑来"获胜"。',
                '我对属于我的人有强烈的保护欲/占有欲。',
                '我有时会因为比较或嫉妒而逼迫自己。',
                '被需要让我感到安全。',
                '我内心有一本账，记录谁值得我的能量。'
            ]
        },
        results: [
            {
                nameEN: 'The Signal (Eleven)',
                nameZH: '信号 (Eleven)',
                scoreRange: [24, 56],
                insightEN: 'Protective, boundary-driven, intuitive. Your shadow is low—you guard what matters.',
                insightZH: '保护性、边界驱动、直觉型。你的阴影较低——你守护重要的事物。',
                nextStepEN: 'Trust your boundaries. They\'re not walls—they\'re signals.',
                nextStepZH: '信任你的边界。它们不是墙——它们是信号。'
            },
            {
                nameEN: 'The Spotlight (Maxine)',
                nameZH: '聚光灯 (Maxine)',
                scoreRange: [57, 88],
                insightEN: 'Ambitious, self-directed, performance-aware. Your shadow is moderate—you know how to play the game.',
                insightZH: '野心、自我导向、表演意识。你的阴影中等——你知道如何玩游戏。',
                nextStepEN: 'Channel ambition into craft. The spotlight follows, not leads.',
                nextStepZH: '将野心转化为技艺。聚光灯跟随，而非引领。'
            },
            {
                nameEN: 'The Mirror (Pearl)',
                nameZH: '镜子 (Pearl)',
                scoreRange: [89, 120],
                insightEN: 'Recognition-hungry, imaginative, comparison-sensitive. Your shadow is high—you see yourself through others.',
                insightZH: '渴望认可、想象力丰富、比较敏感。你的阴影较高——你通过他人看自己。',
                nextStepEN: 'The mirror reflects, not defines. Step back and see the whole frame.',
                nextStepZH: '镜子反映，而非定义。退后一步，看到整个框架。'
            }
        ]
    },
    {
        id: 'power-boundaries',
        titleEN: 'Power & Boundaries',
        titleZH: '权力与边界',
        descEN: '12 questions. Preference & communication style, not behavior instruction. Consent-first.',
        descZH: '12 题。偏好与沟通风格，非行为指导。同意优先。',
        questions: {
            en: [
                'I feel safer when roles/rules are clear.',
                'I like agreeing on boundaries in advance (yes/no/maybe).',
                'I\'m curious about power dynamics only if it\'s safe and consensual.',
                'I prefer predictable intensity rather than surprises.',
                'I value a clear pause/stop system.',
                'I prefer talking through misunderstandings over cold distance.',
                'I want my pace respected, not rushed.',
                'Aftercare/closure matters to me (check-in, reassurance).',
                'I\'m sensitive to shame, so I need gentleness and control.',
                'I\'m attracted to people who are firm but respectful.',
                'Exploration is OK; being pushed is not.',
                'My core safety is: I can say "no" anytime and be taken seriously.'
            ],
            zh: [
                '当角色/规则清晰时，我感到更安全。',
                '我喜欢提前约定边界（是/否/也许）。',
                '只有在安全且双方同意的情况下，我才会对权力动态好奇。',
                '我更喜欢可预测的强度，而不是惊喜。',
                '我重视清晰的暂停/停止系统。',
                '我更喜欢通过沟通解决误解，而不是冷距离。',
                '我希望我的节奏被尊重，不被催促。',
                '事后关怀/结束对我很重要（检查、安慰）。',
                '我对羞耻很敏感，所以我需要温柔和控制。',
                '我被坚定但尊重的人吸引。',
                '探索可以；被推动不行。',
                '我的核心安全是：我可以随时说"不"并被认真对待。'
            ]
        },
        results: [
            {
                nameEN: 'Clear Structure',
                nameZH: '清晰结构',
                scoreRange: [12, 30],
                insightEN: 'You thrive with explicit boundaries and predictable patterns.',
                insightZH: '你在明确的边界和可预测的模式中茁壮成长。',
                nextStepEN: 'Communicate your needs clearly. Structure is safety.',
                nextStepZH: '清晰地沟通你的需求。结构就是安全。'
            },
            {
                nameEN: 'Flexible Balance',
                nameZH: '灵活平衡',
                scoreRange: [31, 48],
                insightEN: 'You navigate between structure and spontaneity with awareness.',
                insightZH: '你有意识地游走在结构与自发性之间。',
                nextStepEN: 'Trust your intuition. Balance is dynamic, not fixed.',
                nextStepZH: '信任你的直觉。平衡是动态的，不是固定的。'
            },
            {
                nameEN: 'Fluid Exploration',
                nameZH: '流动探索',
                scoreRange: [49, 60],
                insightEN: 'You prefer fluid boundaries and open communication.',
                insightZH: '你更喜欢流动的边界和开放的沟通。',
                nextStepEN: 'Maintain awareness even in fluidity. Consent is ongoing.',
                nextStepZH: '即使在流动性中也要保持意识。同意是持续的。'
            }
        ]
    }
];
