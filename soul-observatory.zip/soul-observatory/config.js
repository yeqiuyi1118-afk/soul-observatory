// Configuration File
// Copy this file to config.js and add your actual API key

const CONFIG = {
    GEMINI_API_KEY: "AIzaSyBIMN02HVeOxJQaN8ZIdjkODTb7ySvJ4CA"
};
