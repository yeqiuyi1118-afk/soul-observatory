// Miao Miao (喵喵) - Three-Personality State Machine
// States: world (surface/upside) + mode (eleven/maxine/pearl)

const MiaoMiao = {
    state: {
        world: 'surface', // 'surface' | 'upside'
        mode: 'eleven'    // 'eleven' | 'maxine' | 'pearl'
    },
    
    // Achievement triggers (set to true when event occurs)
    achievements: {
        quizCompleted: false,
        highScore: false,
        rareCard: false
    },
    
    // Response templates by mode
    responses: {
        eleven: {
            greeting: ['I see you.', 'Friends don\'t lie.', 'Safe now.'],
            thinking: ['...', 'Hmm.', 'Checking.'],
            observation: ['Pattern detected.', 'Signal clear.', 'Boundary noted.'],
            risk: ['Watch this.', 'Caution here.', 'Protect yourself.'],
            control: ['You can stop.', 'Say no.', 'Your choice.'],
            nextAction: ['Try this.', 'Explore here.', 'Next step.']
        },
        maxine: {
            greeting: ['You did it.', 'Breakthrough moment.', 'This is it.'],
            thinking: ['Calculating...', 'Analyzing potential...', 'Mapping route...'],
            observation: ['You\'re performing.', 'The spotlight is yours.', 'This is your moment.'],
            risk: ['Don\'t let them underestimate you.', 'Push harder.', 'Take the risk.'],
            control: ['You control this.', 'Own it.', 'Make it yours.'],
            nextAction: ['Go further.', 'Level up.', 'Claim it.']
        },
        pearl: {
            greeting: ['I see the shadow.', 'The mirror reflects.', 'Hidden patterns.'],
            thinking: ['...deeper...', '...layers...', '...truth...'],
            observation: ['Have you ever wanted to steal back the spotlight that was taken from you?', 'Do you ever feel the urge to rewrite the story—no matter the cost?', 'The reflection shows what you hide.'],
            risk: ['The shadow grows.', 'Recognition hunger.', 'Comparison trap.'],
            control: ['Step back from the mirror.', 'See the whole frame.', 'You\'re more than the reflection.'],
            nextAction: ['Acknowledge the shadow.', 'Reframe the story.', 'Choose differently.']
        }
    },
    
    // Update state based on world and achievements
    updateState(world, achievements = null) {
        if (world) {
            this.state.world = world;
        }
        
        if (achievements) {
            Object.assign(this.achievements, achievements);
        }
        
        // State machine rules
        if (this.state.world === 'upside') {
            // Upside world: force pearl mode
            this.state.mode = 'pearl';
        } else if (this.state.world === 'surface') {
            // Surface world: default eleven, but maxine if achievement triggered
            if (this.achievements.quizCompleted || this.achievements.highScore || this.achievements.rareCard) {
                this.state.mode = 'maxine';
                // Reset after 10 seconds
                setTimeout(() => {
                    if (this.state.world === 'surface') {
                        this.state.mode = 'eleven';
                    }
                }, 10000);
            } else {
                this.state.mode = 'eleven';
            }
        }
    },
    
    // Generate response in audit logic format
    generateResponse(context) {
        const mode = this.responses[this.state.mode];
        const lang = window.currentLang || 'en';
        
        // Audit logic: Observation → Risk → Control → Next Action
        const parts = [];
        
        if (context.observation) {
            parts.push(mode.observation[Math.floor(Math.random() * mode.observation.length)]);
        }
        if (context.risk) {
            parts.push(mode.risk[Math.floor(Math.random() * mode.risk.length)]);
        }
        if (context.control) {
            parts.push(mode.control[Math.floor(Math.random() * mode.control.length)]);
        }
        if (context.nextAction) {
            parts.push(mode.nextAction[Math.floor(Math.random() * mode.nextAction.length)]);
        }
        
        return parts.join(' ');
    },
    
    // Get thinking indicator
    getThinking() {
        const mode = this.responses[this.state.mode];
        return mode.thinking[Math.floor(Math.random() * mode.thinking.length)];
    },
    
    // Get greeting
    getGreeting() {
        const mode = this.responses[this.state.mode];
        return mode.greeting[Math.floor(Math.random() * mode.greeting.length)];
    },
    
    // Trigger achievement
    triggerAchievement(type) {
        this.achievements[type] = true;
        this.updateState(null, this.achievements);
    },
    
    // Reset achievements
    resetAchievements() {
        this.achievements = {
            quizCompleted: false,
            highScore: false,
            rareCard: false
        };
        this.updateState(null, this.achievements);
    }
};
