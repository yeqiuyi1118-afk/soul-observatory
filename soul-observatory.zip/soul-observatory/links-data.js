// Archives Data - External Test Links
// Structure: category (EN/ZH) + links array

const archivesData = [
    {
        categoryEN: 'MBTI & 16 Types',
        categoryZH: 'MBTI 与 16 型人格',
        links: [
            { nameEN: '16Personalities', nameZH: '16Personalities', url: 'https://www.16personalities.com/', type: 'Free', langTag: 'EN/ZH' },
            { nameEN: '16Personalities 简中', nameZH: '16Personalities 简中', url: 'https://www.16personalities.com/ch', type: 'Free', langTag: 'ZH' },
            { nameEN: 'Truity', nameZH: 'Truity', url: 'https://www.truity.com/', type: 'Report', langTag: 'EN' }
        ]
    },
    {
        categoryEN: 'Big Five / IPIP',
        categoryZH: '大五人格 / IPIP',
        links: [
            { nameEN: 'OpenPsychometrics Big Five', nameZH: 'OpenPsychometrics 大五', url: 'https://openpsychometrics.org/tests/IPIP-BFFM/', type: 'Free', langTag: 'EN' },
            { nameEN: 'BigFive-Test', nameZH: 'BigFive 测试', url: 'https://bigfive-test.com/en', type: 'Free', langTag: 'EN' },
            { nameEN: 'Personality Assessor (IPIP-300)', nameZH: '人格评估器 (IPIP-300)', url: 'https://www.personalityassessor.com/ipip300/', type: 'Free', langTag: 'EN' },
            { nameEN: 'IPIP Official', nameZH: 'IPIP 官方', url: 'https://ipip.ori.org/', type: 'Research', langTag: 'EN' }
        ]
    },
    {
        categoryEN: 'Attachment & Relationship',
        categoryZH: '依恋与关系',
        links: [
            { nameEN: 'Attachment Project', nameZH: '依恋项目', url: 'https://www.attachmentproject.com/attachment-style-quiz/', type: 'Free', langTag: 'EN' },
            { nameEN: '5 Love Languages', nameZH: '五种爱的语言', url: 'https://5lovelanguages.com/quizzes/love-language', type: 'Free', langTag: 'EN' }
        ]
    },
    {
        categoryEN: 'Career & Interests',
        categoryZH: '职业与兴趣',
        links: [
            { nameEN: 'O*NET Interest Profiler', nameZH: 'O*NET 兴趣分析器', url: 'https://onetinterestprofiler.org/', type: 'Official', langTag: 'EN' },
            { nameEN: 'OpenPsychometrics RIASEC', nameZH: 'OpenPsychometrics RIASEC', url: 'https://openpsychometrics.org/tests/RIASEC/', type: 'Free', langTag: 'EN' },
            { nameEN: '123test Career', nameZH: '123test 职业', url: 'https://www.123test.com/career-test/', type: 'Free', langTag: 'EN' }
        ]
    },
    {
        categoryEN: 'Character Strengths',
        categoryZH: '性格优势',
        links: [
            { nameEN: 'VIA Character Strengths', nameZH: 'VIA 性格优势', url: 'https://www.viacharacter.org/', type: 'Free', langTag: 'EN' }
        ]
    },
    {
        categoryEN: 'Enneagram',
        categoryZH: '九型人格',
        links: [
            { nameEN: 'Truity Enneagram', nameZH: 'Truity 九型', url: 'https://www.truity.com/test/enneagram-personality-test', type: 'Free', langTag: 'EN' },
            { nameEN: 'Enneagram Universe', nameZH: '九型宇宙', url: 'https://enneagramuniverse.com/', type: 'Free', langTag: 'EN' }
        ]
    },
    {
        categoryEN: 'HEXACO',
        categoryZH: 'HEXACO',
        links: [
            { nameEN: 'HEXACO official', nameZH: 'HEXACO 官方', url: 'https://hexaco.org/', type: 'Free', langTag: 'EN' },
            { nameEN: 'IDR Labs HEXACO', nameZH: 'IDR Labs HEXACO', url: 'https://www.idrlabs.com/hexaco/test.php', type: 'Commercial', langTag: 'EN' }
        ]
    },
    {
        categoryEN: 'Chinese Ecosystem',
        categoryZH: '中文生态',
        links: [
            { nameEN: '壹心理测试', nameZH: '壹心理测试', url: 'https://www.xinli001.com/ceshi', type: 'Mix', langTag: 'ZH' },
            { nameEN: '测测 Cece', nameZH: '测测 Cece', url: 'https://www.cece.com/', type: 'Fun', langTag: 'ZH' },
            { nameEN: '知我探索', nameZH: '知我探索', url: 'https://www.zhiwotansuo.cn/', type: 'Mix', langTag: 'ZH' },
            { nameEN: '壹点灵', nameZH: '壹点灵', url: 'https://www.ydl.com/', type: 'Mix', langTag: 'ZH' }
        ]
    }
];
